# Personal Task Manager — Complete Project Files

Copy each section into the corresponding file path in your VS Code project.

---

## `package.json`

```json
{
  "name": "personal-task-manager",
  "private": true,
  "version": "1.0.0",
  "type": "module",
  "scripts": {
    "dev": "vite",
    "build": "vite build",
    "preview": "vite preview"
  },
  "dependencies": {
    "react": "^18.3.1",
    "react-dom": "^18.3.1"
  },
  "devDependencies": {
    "@vitejs/plugin-react": "^4.3.1",
    "vite": "^5.4.0"
  }
}
```

---

## `vite.config.js`

```js
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
})
```

---

## `index.html`

```html
<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Personal Task Manager</title>
  </head>
  <body>
    <div id="root"></div>
    <script type="module" src="/src/main.jsx"></script>
  </body>
</html>
```

---

## `.gitignore`

```
node_modules
dist
dist-ssr
*.local
.DS_Store
.vscode/*
!.vscode/extensions.json
.idea
*.suo
*.ntvs*
*.njsproj
*.sln
*.sw?
```

---

## `src/main.jsx`

```jsx
import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App.jsx'
import './index.css'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
)
```

---

## `src/hooks/useLocalStorage.js`

```js
import { useState, useEffect } from 'react'

export function useLocalStorage(key, initialValue) {
  const [value, setValue] = useState(() => {
    try {
      const stored = localStorage.getItem(key)
      return stored !== null ? JSON.parse(stored) : initialValue
    } catch {
      return initialValue
    }
  })

  useEffect(() => {
    localStorage.setItem(key, JSON.stringify(value))
  }, [key, value])

  return [value, setValue]
}
```

---

## `src/App.jsx`

```jsx
import { useState } from 'react'
import Header from './components/Header.jsx'
import TaskForm from './components/TaskForm.jsx'
import FilterBar from './components/FilterBar.jsx'
import TaskList from './components/TaskList.jsx'
import TaskCounter from './components/TaskCounter.jsx'
import { useLocalStorage } from './hooks/useLocalStorage.js'
import './App.css'

const CATEGORIES = ['Work', 'Personal', 'Urgent', 'Study']

export default function App() {
  const [tasks, setTasks] = useLocalStorage('tasks', [])
  const [theme, setTheme] = useLocalStorage('theme', 'light')
  const [statusFilter, setStatusFilter] = useState('all')
  const [categoryFilter, setCategoryFilter] = useState('all')
  const [editingId, setEditingId] = useState(null)

  const addTask = (title, category, dueDate) => {
    const newTask = {
      id: crypto.randomUUID(),
      title,
      category,
      dueDate,
      completed: false,
      createdAt: Date.now(),
    }
    setTasks((prev) => [newTask, ...prev])
  }

  const deleteTask = (id) => {
    setTasks((prev) => prev.filter((task) => task.id !== id))
  }

  const toggleTask = (id) => {
    setTasks((prev) =>
      prev.map((task) =>
        task.id === id ? { ...task, completed: !task.completed } : task
      )
    )
  }

  const editTask = (id, newTitle) => {
    setTasks((prev) =>
      prev.map((task) => (task.id === id ? { ...task, title: newTitle } : task))
    )
    setEditingId(null)
  }

  const clearCompleted = () => {
    setTasks((prev) => prev.filter((task) => !task.completed))
  }

  const toggleTheme = () => {
    setTheme((prev) => (prev === 'light' ? 'dark' : 'light'))
  }

  const filteredTasks = tasks.filter((task) => {
    const matchesStatus =
      statusFilter === 'all' ||
      (statusFilter === 'active' && !task.completed) ||
      (statusFilter === 'completed' && task.completed)
    const matchesCategory =
      categoryFilter === 'all' || task.category === categoryFilter
    return matchesStatus && matchesCategory
  })

  const activeCount = tasks.filter((task) => !task.completed).length
  const completedCount = tasks.length - activeCount

  return (
    <div className="app" data-theme={theme}>
      <div className="app-container">
        <Header theme={theme} onToggleTheme={toggleTheme} />
        <TaskForm onAdd={addTask} />
        <FilterBar
          statusFilter={statusFilter}
          onStatusChange={setStatusFilter}
          categoryFilter={categoryFilter}
          onCategoryChange={setCategoryFilter}
          categories={CATEGORIES}
        />
        <TaskCounter
          activeCount={activeCount}
          completedCount={completedCount}
          onClearCompleted={clearCompleted}
        />
        <TaskList
          tasks={filteredTasks}
          editingId={editingId}
          onToggle={toggleTask}
          onDelete={deleteTask}
          onEdit={editTask}
          onStartEdit={setEditingId}
          onCancelEdit={() => setEditingId(null)}
          hasAnyTasks={tasks.length > 0}
        />
      </div>
    </div>
  )
}
```

---

## `src/components/Header.jsx`

```jsx
export default function Header({ theme, onToggleTheme }) {
  return (
    <header className="header">
      <h1 className="header-title">Personal Task Manager</h1>
      <button
        className="theme-toggle"
        onClick={onToggleTheme}
        aria-label={`Switch to ${theme === 'light' ? 'dark' : 'light'} mode`}
      >
        {theme === 'light' ? 'Dark Mode' : 'Light Mode'}
      </button>
    </header>
  )
}
```

---

## `src/components/TaskForm.jsx`

```jsx
import { useState } from 'react'

const CATEGORIES = ['Work', 'Personal', 'Urgent', 'Study']

export default function TaskForm({ onAdd }) {
  const [title, setTitle] = useState('')
  const [category, setCategory] = useState('Personal')
  const [dueDate, setDueDate] = useState('')

  const handleSubmit = (e) => {
    e.preventDefault()
    const trimmed = title.trim()
    if (!trimmed) return
    onAdd(trimmed, category, dueDate || null)
    setTitle('')
    setCategory('Personal')
    setDueDate('')
  }

  return (
    <form className="task-form" onSubmit={handleSubmit}>
      <div className="form-row">
        <label htmlFor="task-title" className="visually-hidden">
          Task title
        </label>
        <input
          id="task-title"
          type="text"
          className="form-input"
          placeholder="What needs to be done?"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
        />
      </div>
      <div className="form-row form-row-inline">
        <div className="form-field">
          <label htmlFor="task-category">Category</label>
          <select
            id="task-category"
            className="form-select"
            value={category}
            onChange={(e) => setCategory(e.target.value)}
          >
            {CATEGORIES.map((cat) => (
              <option key={cat} value={cat}>
                {cat}
              </option>
            ))}
          </select>
        </div>
        <div className="form-field">
          <label htmlFor="task-due-date">Due date (optional)</label>
          <input
            id="task-due-date"
            type="date"
            className="form-input"
            value={dueDate}
            onChange={(e) => setDueDate(e.target.value)}
          />
        </div>
        <button type="submit" className="btn btn-primary">
          Add Task
        </button>
      </div>
    </form>
  )
}
```

---

## `src/components/FilterBar.jsx`

```jsx
export default function FilterBar({
  statusFilter,
  onStatusChange,
  categoryFilter,
  onCategoryChange,
  categories,
}) {
  const statusOptions = [
    { value: 'all', label: 'All' },
    { value: 'active', label: 'Active' },
    { value: 'completed', label: 'Completed' },
  ]

  return (
    <div className="filter-bar">
      <div className="filter-group" role="group" aria-label="Filter by status">
        {statusOptions.map((option) => (
          <button
            key={option.value}
            className={`filter-btn ${statusFilter === option.value ? 'active' : ''}`}
            onClick={() => onStatusChange(option.value)}
            aria-pressed={statusFilter === option.value}
          >
            {option.label}
          </button>
        ))}
      </div>
      <div className="filter-group">
        <label htmlFor="category-filter" className="visually-hidden">
          Filter by category
        </label>
        <select
          id="category-filter"
          className="form-select"
          value={categoryFilter}
          onChange={(e) => onCategoryChange(e.target.value)}
        >
          <option value="all">All Categories</option>
          {categories.map((cat) => (
            <option key={cat} value={cat}>
              {cat}
            </option>
          ))}
        </select>
      </div>
    </div>
  )
}
```

---

## `src/components/TaskList.jsx`

```jsx
import TaskItem from './TaskItem.jsx'

export default function TaskList({
  tasks,
  editingId,
  onToggle,
  onDelete,
  onEdit,
  onStartEdit,
  onCancelEdit,
  hasAnyTasks,
}) {
  if (!hasAnyTasks) {
    return <div className="empty-state">No tasks yet – add one above!</div>
  }

  if (tasks.length === 0) {
    return <div className="empty-state">No tasks match the current filters.</div>
  }

  return (
    <ul className="task-list">
      {tasks.map((task) => (
        <TaskItem
          key={task.id}
          task={task}
          isEditing={editingId === task.id}
          onToggle={onToggle}
          onDelete={onDelete}
          onEdit={onEdit}
          onStartEdit={onStartEdit}
          onCancelEdit={onCancelEdit}
        />
      ))}
    </ul>
  )
}
```

---

## `src/components/TaskItem.jsx`

```jsx
import { useState } from 'react'

export default function TaskItem({
  task,
  isEditing,
  onToggle,
  onDelete,
  onEdit,
  onStartEdit,
  onCancelEdit,
}) {
  const [editText, setEditText] = useState(task.title)

  const handleSave = () => {
    const trimmed = editText.trim()
    if (!trimmed) return
    onEdit(task.id, trimmed)
  }

  const handleCancel = () => {
    setEditText(task.title)
    onCancelEdit()
  }

  const isOverdue =
    !task.completed &&
    task.dueDate &&
    new Date(task.dueDate + 'T23:59:59') < new Date()

  return (
    <li className={`task-item ${task.completed ? 'completed' : ''}`}>
      <div className="task-main">
        <input
          type="checkbox"
          className="task-checkbox"
          checked={task.completed}
          onChange={() => onToggle(task.id)}
          aria-label={`Mark "${task.title}" as ${task.completed ? 'incomplete' : 'complete'}`}
        />
        {isEditing ? (
          <div className="edit-mode">
            <input
              type="text"
              className="edit-input"
              value={editText}
              onChange={(e) => setEditText(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') handleSave()
                if (e.key === 'Escape') handleCancel()
              }}
              autoFocus
              aria-label="Edit task title"
            />
            <div className="edit-actions">
              <button className="btn btn-primary btn-small" onClick={handleSave}>
                Save
              </button>
              <button className="btn btn-secondary btn-small" onClick={handleCancel}>
                Cancel
              </button>
            </div>
          </div>
        ) : (
          <div className="task-content">
            <span className="task-title">{task.title}</span>
            <div className="task-meta">
              <span className={`badge badge-${task.category.toLowerCase()}`}>
                {task.category}
              </span>
              {task.dueDate && (
                <span className={`due-date ${isOverdue ? 'overdue' : ''}`}>
                  {isOverdue ? 'Overdue: ' : 'Due: '}
                  {new Date(task.dueDate + 'T00:00:00').toLocaleDateString()}
                </span>
              )}
            </div>
          </div>
        )}
      </div>
      {!isEditing && (
        <div className="task-actions">
          <button
            className="btn btn-secondary btn-small"
            onClick={() => {
              setEditText(task.title)
              onStartEdit(task.id)
            }}
            aria-label={`Edit "${task.title}"`}
          >
            Edit
          </button>
          <button
            className="btn btn-danger btn-small"
            onClick={() => onDelete(task.id)}
            aria-label={`Delete "${task.title}"`}
          >
            Delete
          </button>
        </div>
      )}
    </li>
  )
}
```

---

## `src/components/TaskCounter.jsx`

```jsx
export default function TaskCounter({ activeCount, completedCount, onClearCompleted }) {
  return (
    <div className="task-counter">
      <span className="counter-text">
        {activeCount} active • {completedCount} completed
      </span>
      {completedCount > 0 && (
        <button className="btn btn-secondary btn-small" onClick={onClearCompleted}>
          Clear completed
        </button>
      )}
    </div>
  )
}
```

---

## `src/index.css`

```css
:root {
  --bg: #f4f6fb;
  --surface: #ffffff;
  --text: #1a1d23;
  --text-muted: #6b7280;
  --border: #e2e8f0;
  --primary: #4f46e5;
  --primary-hover: #4338ca;
  --danger: #dc2626;
  --danger-hover: #b91c1c;
  --secondary: #e2e8f0;
  --secondary-hover: #cbd5e1;
  --shadow: 0 1px 3px rgba(0, 0, 0, 0.08), 0 4px 12px rgba(0, 0, 0, 0.04);
  --badge-work: #3b82f6;
  --badge-personal: #10b981;
  --badge-urgent: #ef4444;
  --badge-study: #f59e0b;
  --overdue: #dc2626;
}

[data-theme='dark'] {
  --bg: #0f1117;
  --surface: #1a1d27;
  --text: #e5e7eb;
  --text-muted: #9ca3af;
  --border: #2d3140;
  --primary: #6366f1;
  --primary-hover: #818cf8;
  --danger: #f87171;
  --danger-hover: #ef4444;
  --secondary: #2d3140;
  --secondary-hover: #3d4152;
  --shadow: 0 1px 3px rgba(0, 0, 0, 0.3), 0 4px 12px rgba(0, 0, 0, 0.2);
  --badge-work: #60a5fa;
  --badge-personal: #34d399;
  --badge-urgent: #f87171;
  --badge-study: #fbbf24;
  --overdue: #f87171;
}

*,
*::before,
*::after {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
}

body {
  font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
  background-color: var(--bg);
  color: var(--text);
  line-height: 1.5;
  transition: background-color 0.3s ease, color 0.3s ease;
}

.visually-hidden {
  position: absolute;
  width: 1px;
  height: 1px;
  padding: 0;
  margin: -1px;
  overflow: hidden;
  clip: rect(0, 0, 0, 0);
  white-space: nowrap;
  border: 0;
}
```

---

## `src/App.css`

```css
.app {
  min-height: 100vh;
  padding: 2rem 1rem;
}

.app-container {
  max-width: 600px;
  margin: 0 auto;
  display: flex;
  flex-direction: column;
  gap: 1.25rem;
}

/* Header */
.header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  flex-wrap: wrap;
  gap: 0.75rem;
}

.header-title {
  font-size: 1.5rem;
  font-weight: 700;
}

.theme-toggle {
  padding: 0.5rem 1rem;
  border: 1px solid var(--border);
  border-radius: 8px;
  background: var(--surface);
  color: var(--text);
  cursor: pointer;
  font-size: 0.875rem;
  transition: background 0.2s ease, border-color 0.2s ease;
}

.theme-toggle:hover {
  background: var(--secondary);
}

.theme-toggle:focus-visible {
  outline: 2px solid var(--primary);
  outline-offset: 2px;
}

/* Task Form */
.task-form {
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: 12px;
  padding: 1.25rem;
  box-shadow: var(--shadow);
  display: flex;
  flex-direction: column;
  gap: 1rem;
}

.form-row {
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
}

.form-row-inline {
  flex-direction: row;
  flex-wrap: wrap;
  align-items: flex-end;
}

.form-field {
  display: flex;
  flex-direction: column;
  gap: 0.35rem;
  flex: 1;
  min-width: 140px;
}

.form-field label {
  font-size: 0.8rem;
  font-weight: 600;
  color: var(--text-muted);
}

.form-input,
.form-select {
  padding: 0.6rem 0.75rem;
  border: 1px solid var(--border);
  border-radius: 8px;
  background: var(--bg);
  color: var(--text);
  font-size: 0.9rem;
  transition: border-color 0.2s ease;
}

.form-input:focus,
.form-select:focus {
  outline: none;
  border-color: var(--primary);
}

/* Buttons */
.btn {
  padding: 0.6rem 1.1rem;
  border: none;
  border-radius: 8px;
  font-size: 0.875rem;
  font-weight: 600;
  cursor: pointer;
  transition: background 0.2s ease, transform 0.1s ease;
}

.btn:active {
  transform: scale(0.97);
}

.btn:focus-visible {
  outline: 2px solid var(--primary);
  outline-offset: 2px;
}

.btn-primary {
  background: var(--primary);
  color: #fff;
}

.btn-primary:hover {
  background: var(--primary-hover);
}

.btn-secondary {
  background: var(--secondary);
  color: var(--text);
}

.btn-secondary:hover {
  background: var(--secondary-hover);
}

.btn-danger {
  background: var(--danger);
  color: #fff;
}

.btn-danger:hover {
  background: var(--danger-hover);
}

.btn-small {
  padding: 0.35rem 0.7rem;
  font-size: 0.8rem;
}

/* Filter Bar */
.filter-bar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  flex-wrap: wrap;
  gap: 0.75rem;
}

.filter-group {
  display: flex;
  align-items: center;
  gap: 0.5rem;
}

.filter-btn {
  padding: 0.45rem 0.9rem;
  border: 1px solid var(--border);
  border-radius: 20px;
  background: var(--surface);
  color: var(--text);
  font-size: 0.8rem;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.2s ease;
}

.filter-btn:hover {
  border-color: var(--primary);
  color: var(--primary);
}

.filter-btn.active {
  background: var(--primary);
  border-color: var(--primary);
  color: #fff;
}

.filter-btn:focus-visible {
  outline: 2px solid var(--primary);
  outline-offset: 2px;
}

/* Task Counter */
.task-counter {
  display: flex;
  align-items: center;
  justify-content: space-between;
  flex-wrap: wrap;
  gap: 0.5rem;
}

.counter-text {
  font-size: 0.875rem;
  color: var(--text-muted);
  font-weight: 500;
}

/* Task List */
.task-list {
  list-style: none;
  display: flex;
  flex-direction: column;
  gap: 0.75rem;
}

.task-item {
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: 12px;
  padding: 1rem 1.25rem;
  box-shadow: var(--shadow);
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 1rem;
  flex-wrap: wrap;
  transition: opacity 0.2s ease;
}

.task-item.completed {
  opacity: 0.65;
}

.task-main {
  display: flex;
  align-items: flex-start;
  gap: 0.75rem;
  flex: 1;
  min-width: 200px;
}

.task-checkbox {
  width: 1.1rem;
  height: 1.1rem;
  margin-top: 0.2rem;
  accent-color: var(--primary);
  cursor: pointer;
  flex-shrink: 0;
}

.task-content {
  display: flex;
  flex-direction: column;
  gap: 0.4rem;
  flex: 1;
}

.task-title {
  font-size: 0.95rem;
  font-weight: 500;
  word-break: break-word;
}

.task-item.completed .task-title {
  text-decoration: line-through;
  color: var(--text-muted);
}

.task-meta {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  flex-wrap: wrap;
}

.badge {
  display: inline-block;
  padding: 0.15rem 0.55rem;
  border-radius: 12px;
  font-size: 0.7rem;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.03em;
  color: #fff;
}

.badge-work {
  background: var(--badge-work);
}

.badge-personal {
  background: var(--badge-personal);
}

.badge-urgent {
  background: var(--badge-urgent);
}

.badge-study {
  background: var(--badge-study);
}

.due-date {
  font-size: 0.75rem;
  color: var(--text-muted);
}

.due-date.overdue {
  color: var(--overdue);
  font-weight: 700;
}

.task-actions {
  display: flex;
  gap: 0.4rem;
  flex-shrink: 0;
}

/* Edit Mode */
.edit-mode {
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
  flex: 1;
}

.edit-input {
  padding: 0.5rem 0.7rem;
  border: 1px solid var(--primary);
  border-radius: 8px;
  background: var(--bg);
  color: var(--text);
  font-size: 0.9rem;
  width: 100%;
}

.edit-input:focus {
  outline: none;
  border-color: var(--primary);
  box-shadow: 0 0 0 2px rgba(99, 102, 241, 0.2);
}

.edit-actions {
  display: flex;
  gap: 0.4rem;
}

/* Empty State */
.empty-state {
  text-align: center;
  padding: 3rem 1.5rem;
  background: var(--surface);
  border: 1px dashed var(--border);
  border-radius: 12px;
  color: var(--text-muted);
  font-size: 0.95rem;
}

/* Responsive */
@media (max-width: 600px) {
  .app {
    padding: 1rem 0.75rem;
  }

  .header-title {
    font-size: 1.25rem;
  }

  .form-row-inline {
    flex-direction: column;
    align-items: stretch;
  }

  .filter-bar {
    flex-direction: column;
    align-items: stretch;
  }

  .filter-group {
    justify-content: center;
  }

  .task-item {
    flex-direction: column;
    align-items: stretch;
  }

  .task-actions {
    justify-content: flex-end;
  }
}
```

---

## `README.md`

```markdown
# Personal Task Manager

A clean, responsive to-do application built with React and Vite. Add, edit, delete, and organize tasks by category with due date tracking, dark/light theme support, and localStorage persistence.

## Features

- Add tasks with a title, category, and optional due date
- Edit tasks inline with Save/Cancel support
- Delete tasks
- Mark tasks complete/incomplete with a checkbox (completed tasks get a strikethrough)
- Filter tasks by status: All / Active / Completed
- Filter tasks by category: Work / Personal / Urgent / Study
- Color-coded category badges
- Overdue indicator for past-due incomplete tasks
- Dark/light theme toggle persisted in localStorage
- Live task counter with "Clear completed" button
- Fully responsive layout (mobile + desktop)
- All data persisted in localStorage

## Technologies Used

- React 18
- Vite 5
- Plain CSS (CSS variables for theming)
- JavaScript (JSX)

## Setup

```bash
npm install
npm run dev
```

Then open http://localhost:5173 in your browser.

## Screenshots

### Home
![Home](screenshots/home.png)

### Filtered View
![Filtered](screenshots/filtered.png)

### Dark Mode
![Dark Mode](screenshots/dark-mode.png)

## Live Demo

[Live Demo](https://your-demo-link.vercel.app)

## Known Limitations

- No backend — all data is stored in the browser's localStorage
- No drag-and-drop reordering
- No subtasks or nested tasks
- No notifications or reminders
```
