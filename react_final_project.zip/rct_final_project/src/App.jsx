import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { KanbanView } from './components/KanbanView';
import { CanvasView } from './components/CanvasView';
import { GanttView } from './components/GanttView';
import { EisenhowerMatrix } from './components/EisenhowerMatrix';
import { CalendarView } from './components/CalendarView';
import { AnalyticsDashboard } from './components/AnalyticsDashboard';
import { FocusHub } from './components/FocusHub';
import { AutomationView } from './components/AutomationView';
import { TaskModal } from './components/TaskModal';
import { AiAssistantModal } from './components/AiAssistantModal';
import { CommandPalette } from './components/CommandPalette';
import { PersonalTaskbar } from './components/PersonalTaskbar';

import { INITIAL_WORKSPACES, INITIAL_TASKS, INITIAL_AUTOMATIONS } from './utils/initialData';
import { soundFx } from './utils/audio';

export default function App() {
  // Persistence State
  const [workspaces, setWorkspaces] = useState(() => {
    const saved = localStorage.getItem('nexus_workspaces');
    return saved ? JSON.parse(saved) : INITIAL_WORKSPACES;
  });

  const [activeWorkspaceId, setActiveWorkspaceId] = useState('ws-eng');

  const [tasks, setTasks] = useState(() => {
    const saved = localStorage.getItem('nexus_tasks');
    return saved ? JSON.parse(saved) : INITIAL_TASKS;
  });

  const [automations, setAutomations] = useState(() => {
    const saved = localStorage.getItem('nexus_automations');
    return saved ? JSON.parse(saved) : INITIAL_AUTOMATIONS;
  });

  // UI State
  const [activeView, setActiveView] = useState('kanban');
  const [theme, setTheme] = useState(() => localStorage.getItem('nexus_theme') || 'dark');
  const [isMuted, setIsMuted] = useState(false);

  // Modals State
  const [activeTaskModal, setActiveTaskModal] = useState(null);
  const [isNewTaskModal, setIsNewTaskModal] = useState(false);
  const [isAiModalOpen, setIsAiModalOpen] = useState(false);
  const [isCommandPaletteOpen, setIsCommandPaletteOpen] = useState(false);

  // Sync state to LocalStorage & HTML data-theme
  useEffect(() => {
    localStorage.setItem('nexus_workspaces', JSON.stringify(workspaces));
  }, [workspaces]);

  useEffect(() => {
    localStorage.setItem('nexus_tasks', JSON.stringify(tasks));
  }, [tasks]);

  useEffect(() => {
    localStorage.setItem('nexus_automations', JSON.stringify(automations));
  }, [automations]);

  useEffect(() => {
    localStorage.setItem('nexus_theme', theme);
    document.documentElement.setAttribute('data-theme', theme);
  }, [theme]);

  // Global Keyboard Shortcuts (Ctrl+K for Command Palette)
  useEffect(() => {
    const handleKeyDown = (e) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setIsCommandPaletteOpen(prev => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Filter tasks for active workspace
  const workspaceTasks = tasks.filter(t => t.workspaceId === activeWorkspaceId);

  // Task Actions
  const handleSaveTask = (taskData) => {
    soundFx.playClick();
    if (isNewTaskModal) {
      const newTask = {
        ...taskData,
        id: `task-${Date.now()}`,
        workspaceId: activeWorkspaceId,
        createdAt: new Date().toISOString().split('T')[0]
      };
      setTasks(prev => [newTask, ...prev]);
    } else {
      setTasks(prev => prev.map(t => t.id === taskData.id ? { ...taskData, updatedAt: new Date().toISOString().split('T')[0] } : t));
    }
    setActiveTaskModal(null);
  };

  const handleDeleteTask = (taskId) => {
    soundFx.playClick();
    setTasks(prev => prev.filter(t => t.id !== taskId));
    setActiveTaskModal(null);
  };

  const handleUpdateTaskStatus = (taskId, newStatus) => {
    soundFx.playClick();
    if (newStatus === 'done') soundFx.playSuccess();
    setTasks(prev => prev.map(t => t.id === taskId ? { ...t, status: newStatus } : t));
  };

  const handleUpdateTaskQuadrant = (taskId, newQuadrant) => {
    soundFx.playClick();
    setTasks(prev => prev.map(t => t.id === taskId ? { ...t, matrixQuadrant: newQuadrant } : t));
  };

  const handleUpdateTaskCanvasPosition = (taskId, newPos) => {
    setTasks(prev => prev.map(t => t.id === taskId ? { ...t, canvasPosition: newPos } : t));
  };

  const handleAddDependency = (taskId, parentId) => {
    soundFx.playSuccess();
    setTasks(prev => prev.map(t => {
      if (t.id === taskId) {
        const deps = t.dependencies || [];
        if (!deps.includes(parentId)) {
          return { ...t, dependencies: [...deps, parentId] };
        }
      }
      return t;
    }));
  };

  // Quick Add helpers
  const handleQuickAddTask = (title, status = 'todo', priority = 'medium', category = 'personal') => {
    soundFx.playClick();
    const newTask = {
      id: `task-${Date.now()}`,
      workspaceId: activeWorkspaceId,
      title,
      status,
      priority,
      category,
      createdAt: new Date().toISOString().split('T')[0],
      canvasPosition: { x: Math.floor(Math.random() * 400) + 100, y: Math.floor(Math.random() * 300) + 100 }
    };
    setTasks(prev => [newTask, ...prev]);
  };

  const handleQuickAddTaskAtPosition = (title, pos) => {
    soundFx.playClick();
    const newTask = {
      id: `task-${Date.now()}`,
      workspaceId: activeWorkspaceId,
      title,
      status: 'todo',
      priority: 'medium',
      category: 'feature',
      createdAt: new Date().toISOString().split('T')[0],
      canvasPosition: pos
    };
    setTasks(prev => [newTask, ...prev]);
  };

  const handleQuickAddTaskQuadrant = (title, quadrant) => {
    soundFx.playClick();
    const newTask = {
      id: `task-${Date.now()}`,
      workspaceId: activeWorkspaceId,
      title,
      status: 'todo',
      priority: 'high',
      category: 'feature',
      matrixQuadrant: quadrant,
      createdAt: new Date().toISOString().split('T')[0]
    };
    setTasks(prev => [newTask, ...prev]);
  };

  const handleQuickAddTaskAtDate = (title, dueDate) => {
    soundFx.playClick();
    const newTask = {
      id: `task-${Date.now()}`,
      workspaceId: activeWorkspaceId,
      title,
      status: 'todo',
      priority: 'medium',
      category: 'feature',
      dueDate,
      createdAt: new Date().toISOString().split('T')[0]
    };
    setTasks(prev => [newTask, ...prev]);
  };

  const handleBatchAddTasks = (newTasksList) => {
    const formatted = newTasksList.map((t, idx) => ({
      ...t,
      id: `task-${Date.now()}-${idx}`,
      workspaceId: activeWorkspaceId,
      createdAt: new Date().toISOString().split('T')[0],
      canvasPosition: { x: 100 + (idx * 250), y: 150 }
    }));
    setTasks(prev => [...formatted, ...prev]);
  };

  // Theme & Sound Toggle
  const handleToggleTheme = () => {
    soundFx.playClick();
    setTheme(prev => prev === 'dark' ? 'cyberpunk' : prev === 'cyberpunk' ? 'light' : 'dark');
  };

  const handleToggleSound = () => {
    setIsMuted(prev => {
      soundFx.isMuted = !prev;
      return !prev;
    });
  };

  // Export / Import Workspace Data
  const handleExportData = () => {
    soundFx.playClick();
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify({ workspaces, tasks, automations }, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", `personal_taskbar_workspace_backup_${new Date().toISOString().split('T')[0]}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  return (
    <div style={{ minHeight: '100vh', background: 'var(--bg-primary)', color: 'var(--text-primary)' }}>
      {/* Top Navbar */}
      <Navbar
        workspaces={workspaces}
        activeWorkspaceId={activeWorkspaceId}
        onSelectWorkspace={setActiveWorkspaceId}
        activeView={activeView}
        onSelectView={setActiveView}
        onOpenNewTaskModal={() => { setIsNewTaskModal(true); setActiveTaskModal({}); }}
        onOpenAiModal={() => setIsAiModalOpen(true)}
        onOpenCommandPalette={() => setIsCommandPaletteOpen(true)}
        theme={theme}
        onToggleTheme={handleToggleTheme}
        isMuted={isMuted}
        onToggleSound={handleToggleSound}
        onExportData={handleExportData}
      />

      {/* Main View Container */}
      <main style={{ width: '100%', height: 'calc(100vh - 110px)', overflow: 'hidden' }}>
        {activeView === 'kanban' && (
          <KanbanView
            tasks={workspaceTasks}
            onUpdateTaskStatus={handleUpdateTaskStatus}
            onDeleteTask={handleDeleteTask}
            onOpenTaskModal={(task) => { setIsNewTaskModal(false); setActiveTaskModal(task); }}
            onQuickAddTask={handleQuickAddTask}
          />
        )}

        {activeView === 'canvas' && (
          <CanvasView
            tasks={workspaceTasks}
            onUpdateTaskCanvasPosition={handleUpdateTaskCanvasPosition}
            onAddDependency={handleAddDependency}
            onOpenTaskModal={(task) => { setIsNewTaskModal(false); setActiveTaskModal(task); }}
            onQuickAddTaskAtPosition={handleQuickAddTaskAtPosition}
          />
        )}

        {activeView === 'gantt' && (
          <GanttView
            tasks={workspaceTasks}
            onOpenTaskModal={(task) => { setIsNewTaskModal(false); setActiveTaskModal(task); }}
          />
        )}

        {activeView === 'matrix' && (
          <EisenhowerMatrix
            tasks={workspaceTasks}
            onUpdateTaskQuadrant={handleUpdateTaskQuadrant}
            onOpenTaskModal={(task) => { setIsNewTaskModal(false); setActiveTaskModal(task); }}
            onQuickAddTaskQuadrant={handleQuickAddTaskQuadrant}
          />
        )}

        {activeView === 'calendar' && (
          <CalendarView
            tasks={workspaceTasks}
            onOpenTaskModal={(task) => { setIsNewTaskModal(false); setActiveTaskModal(task); }}
            onQuickAddTaskAtDate={handleQuickAddTaskAtDate}
          />
        )}

        {activeView === 'analytics' && (
          <AnalyticsDashboard tasks={workspaceTasks} />
        )}

        {activeView === 'focus' && (
          <FocusHub tasks={workspaceTasks} />
        )}

        {activeView === 'automations' && (
          <AutomationView
            automations={automations}
            onToggleAutomation={(id) => setAutomations(prev => prev.map(a => a.id === id ? { ...a, enabled: !a.enabled } : a))}
            onAddAutomation={(newRule) => setAutomations(prev => [newRule, ...prev])}
          />
        )}
      </main>

      {/* Task Modal (Create / Edit) */}
      {activeTaskModal !== null && (
        <TaskModal
          task={activeTaskModal}
          isNew={isNewTaskModal}
          onClose={() => setActiveTaskModal(null)}
          onSave={handleSaveTask}
          onDelete={handleDeleteTask}
        />
      )}

      {/* AI Copilot Blueprint Modal */}
      {isAiModalOpen && (
        <AiAssistantModal
          onClose={() => setIsAiModalOpen(false)}
          onBatchAddTasks={handleBatchAddTasks}
        />
      )}

      {/* Floating Personal Taskbar / Dock */}
      <PersonalTaskbar
        tasks={workspaceTasks}
        activeView={activeView}
        onSelectView={setActiveView}
        onQuickAddTask={handleQuickAddTask}
        onOpenNewTaskModal={() => { setIsNewTaskModal(true); setActiveTaskModal({}); }}
        onOpenAiModal={() => setIsAiModalOpen(true)}
        onOpenCommandPalette={() => setIsCommandPaletteOpen(true)}
      />

      {/* Ctrl+K Command Palette */}
      <CommandPalette
        isOpen={isCommandPaletteOpen}
        onClose={() => setIsCommandPaletteOpen(false)}
        tasks={workspaceTasks}
        onSelectView={setActiveView}
        onOpenTaskModal={(task) => { setIsNewTaskModal(false); setActiveTaskModal(task); }}
        onToggleTheme={handleToggleTheme}
        onOpenNewTaskModal={() => { setIsNewTaskModal(true); setActiveTaskModal({}); }}
        onOpenAiModal={() => setIsAiModalOpen(true)}
      />
    </div>
  );
}
