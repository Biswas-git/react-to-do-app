// Initial Pre-populated Workspaces and Tasks for NexusOS

const today = new Date();
const formatDate = (daysOffset) => {
  const d = new Date(today);
  d.setDate(d.getDate() + daysOffset);
  return d.toISOString().split('T')[0];
};

export const INITIAL_WORKSPACES = [
  { id: 'ws-eng', name: 'Engineering & Product Hub', icon: 'Code', color: '#6366f1' },
  { id: 'ws-design', name: 'UI/UX Design Studio', icon: 'Palette', color: '#ec4899' },
  { id: 'ws-startup', name: 'Startup Growth & Ops', icon: 'Rocket', color: '#10b981' },
  { id: 'ws-personal', name: 'Personal Growth OS', icon: 'User', color: '#f59e0b' }
];

export const INITIAL_TASKS = [
  // Engineering Workspace Tasks
  {
    id: 'task-101',
    workspaceId: 'ws-eng',
    title: 'Architect NextGen Real-Time Sync Engine',
    description: 'Design WebSocket event mesh with WebRTC fallback for multi-tenant data synchronization.',
    status: 'in_progress',
    priority: 'critical',
    category: 'feature',
    startDate: formatDate(-3),
    dueDate: formatDate(4),
    estimatedHours: 12,
    loggedHours: 6,
    tags: ['Architecture', 'WebSockets', 'Core'],
    subtasks: [
      { id: 'st-101-1', title: 'Draft sequence diagram & payload contract', completed: true },
      { id: 'st-101-2', title: 'Implement WebSocket reconnection handler', completed: true },
      { id: 'st-101-3', title: 'Write conflict resolution (CRDT) module', completed: false },
      { id: 'st-101-4', title: 'Bench test 10k concurrent connections', completed: false }
    ],
    dependencies: [],
    canvasPosition: { x: 100, y: 120 },
    matrixQuadrant: 'do_first',
    createdAt: formatDate(-5),
    updatedAt: formatDate(-1)
  },
  {
    id: 'task-102',
    workspaceId: 'ws-eng',
    title: 'Implement OAuth2 PKCE Authentication',
    description: 'Integrate secure JWT token rotation and social login providers (GitHub, Google).',
    status: 'review',
    priority: 'high',
    category: 'feature',
    startDate: formatDate(-5),
    dueDate: formatDate(1),
    estimatedHours: 8,
    loggedHours: 7,
    tags: ['Security', 'Auth', 'Backend'],
    subtasks: [
      { id: 'st-102-1', title: 'Setup Auth0 / Supabase client credentials', completed: true },
      { id: 'st-102-2', title: 'Build refresh token rotation middleware', completed: true },
      { id: 'st-102-3', title: 'Add session revocation API endpoint', completed: true },
      { id: 'st-102-4', title: 'Audit token storage in HTTP-only cookies', completed: false }
    ],
    dependencies: ['task-101'],
    canvasPosition: { x: 450, y: 120 },
    matrixQuadrant: 'do_first',
    createdAt: formatDate(-6),
    updatedAt: formatDate(0)
  },
  {
    id: 'task-103',
    workspaceId: 'ws-eng',
    title: 'Optimize WebGL Canvas Rendering Performance',
    description: 'Reduce memory overhead and achieve steady 60FPS for complex node spatial graph.',
    status: 'todo',
    priority: 'medium',
    category: 'feature',
    startDate: formatDate(1),
    dueDate: formatDate(7),
    estimatedHours: 10,
    loggedHours: 0,
    tags: ['Performance', 'Canvas', 'Frontend'],
    subtasks: [
      { id: 'st-103-1', title: 'Profile memory leaks with Chrome DevTools', completed: false },
      { id: 'st-103-2', title: 'Implement offscreen canvas worker rendering', completed: false },
      { id: 'st-103-3', title: 'Add spatial viewport culling algorithm', completed: false }
    ],
    dependencies: ['task-101'],
    canvasPosition: { x: 800, y: 120 },
    matrixQuadrant: 'schedule',
    createdAt: formatDate(-2),
    updatedAt: formatDate(-2)
  },
  {
    id: 'task-104',
    workspaceId: 'ws-eng',
    title: 'Fix Memory Leak in Audio Synth Worker',
    description: 'Web Audio context oscillators were not disconnecting properly upon timer reset.',
    status: 'done',
    priority: 'critical',
    category: 'bug',
    startDate: formatDate(-4),
    dueDate: formatDate(-1),
    estimatedHours: 3,
    loggedHours: 3,
    tags: ['Bug', 'Audio', 'Hotfix'],
    subtasks: [
      { id: 'st-104-1', title: 'Isolate node leaks in soundFx.stopAmbient()', completed: true },
      { id: 'st-104-2', title: 'Explicitly invoke disconnect() on gain nodes', completed: true }
    ],
    dependencies: [],
    canvasPosition: { x: 100, y: 400 },
    matrixQuadrant: 'do_first',
    createdAt: formatDate(-4),
    updatedAt: formatDate(-1)
  },
  {
    id: 'task-105',
    workspaceId: 'ws-eng',
    title: 'Setup Automated CI/CD Pipeline on GitHub Actions',
    description: 'Run unit test suite, linting, build validation, and Vercel preview deployment.',
    status: 'backlog',
    priority: 'low',
    category: 'research',
    startDate: formatDate(5),
    dueDate: formatDate(12),
    estimatedHours: 5,
    loggedHours: 0,
    tags: ['DevOps', 'CI/CD', 'Automation'],
    subtasks: [
      { id: 'st-105-1', title: 'Write main.yml GitHub action script', completed: false },
      { id: 'st-105-2', title: 'Configure Vercel token secrets', completed: false }
    ],
    dependencies: [],
    canvasPosition: { x: 450, y: 400 },
    matrixQuadrant: 'delegate',
    createdAt: formatDate(-1),
    updatedAt: formatDate(-1)
  },

  // Design Workspace Tasks
  {
    id: 'task-201',
    workspaceId: 'ws-design',
    title: 'Design Dark Glassmorphism Component Library',
    description: 'Create unified Figma design system tokens for buttons, cards, modals, and inputs.',
    status: 'in_progress',
    priority: 'high',
    category: 'design',
    startDate: formatDate(-2),
    dueDate: formatDate(3),
    estimatedHours: 8,
    loggedHours: 4,
    tags: ['Figma', 'Glassmorphism', 'Tokens'],
    subtasks: [
      { id: 'st-201-1', title: 'Define HSL color palette & glowing borders', completed: true },
      { id: 'st-201-2', title: 'Build component variant library in Figma', completed: true },
      { id: 'st-201-3', title: 'Export SVG icon pack & typography rules', completed: false }
    ],
    dependencies: [],
    canvasPosition: { x: 150, y: 150 },
    matrixQuadrant: 'do_first',
    createdAt: formatDate(-3),
    updatedAt: formatDate(0)
  },
  {
    id: 'task-202',
    workspaceId: 'ws-design',
    title: 'User Experience Audit & Usability Testing',
    description: 'Conduct interactive user testing sessions with 5 beta testers on spatial canvas.',
    status: 'todo',
    priority: 'medium',
    category: 'research',
    startDate: formatDate(2),
    dueDate: formatDate(8),
    estimatedHours: 6,
    loggedHours: 0,
    tags: ['UX', 'Usability', 'Feedback'],
    subtasks: [
      { id: 'st-202-1', title: 'Prepare usability test scenario script', completed: false },
      { id: 'st-202-2', title: 'Record screen sessions & log friction points', completed: false }
    ],
    dependencies: ['task-201'],
    canvasPosition: { x: 500, y: 150 },
    matrixQuadrant: 'schedule',
    createdAt: formatDate(-1),
    updatedAt: formatDate(-1)
  }
];

export const INITIAL_AUTOMATIONS = [
  {
    id: 'auto-1',
    name: 'Auto-promote Critical Tasks to Do First',
    trigger: 'Priority Changed to Critical',
    condition: 'Status is not Done',
    action: 'Move to Eisenhower "Do First" Quadrant',
    enabled: true,
    executions: 14
  },
  {
    id: 'auto-2',
    name: 'Auto-Complete Task when all Subtasks are Checked',
    trigger: 'Subtasks hit 100%',
    condition: 'Status is In Progress',
    action: 'Set Task Status to Completed & Play Chime',
    enabled: true,
    executions: 28
  },
  {
    id: 'auto-3',
    name: 'Overdue Task Alert Tag',
    trigger: 'Due Date Passed',
    condition: 'Status is Pending',
    action: 'Add Tag "Overdue" and Set Priority to High',
    enabled: true,
    executions: 5
  }
];
