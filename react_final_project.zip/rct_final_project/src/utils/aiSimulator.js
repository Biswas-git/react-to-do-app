// AI Assistant Engine & Task Generator Simulator for NexusOS

export const aiAssistant = {
  // Auto breakdown task into structured subtasks based on keywords and context
  generateSubtasks: (taskTitle, category = 'feature') => {
    const title = taskTitle.toLowerCase();
    
    if (title.includes('auth') || title.includes('login') || title.includes('user')) {
      return [
        { id: 'st-1', title: 'Design DB Schema & User Tokens', completed: true },
        { id: 'st-2', title: 'Build OAuth2 / JWT Auth Controllers', completed: false },
        { id: 'st-3', title: 'Create Login & Sign Up UI Forms', completed: false },
        { id: 'st-4', title: 'Setup Middleware & Protected Routes', completed: false },
        { id: 'st-5', title: 'Write Integration Tests & Security Audit', completed: false }
      ];
    }

    if (title.includes('api') || title.includes('backend') || title.includes('database')) {
      return [
        { id: 'st-1', title: 'Define OpenAPI / REST Specification', completed: true },
        { id: 'st-2', title: 'Implement CRUD Endpoints & Validators', completed: false },
        { id: 'st-3', title: 'Setup DB Migration & Indexing', completed: false },
        { id: 'st-4', title: 'Add Rate Limiting & Error Handlers', completed: false }
      ];
    }

    if (title.includes('ui') || title.includes('design') || title.includes('landing') || title.includes('dashboard')) {
      return [
        { id: 'st-1', title: 'Draft High-Fidelity Figma Wireframes', completed: true },
        { id: 'st-2', title: 'Establish CSS Design Tokens & Color Palette', completed: true },
        { id: 'st-3', title: 'Build Responsive Component Layouts', completed: false },
        { id: 'st-4', title: 'Add Micro-Animations & Dark Mode support', completed: false },
        { id: 'st-5', title: 'Conduct Accessibility & Screen Reader Audit', completed: false }
      ];
    }

    if (title.includes('bug') || title.includes('fix') || title.includes('error')) {
      return [
        { id: 'st-1', title: 'Reproduce issue in isolated dev container', completed: true },
        { id: 'st-2', title: 'Inspect browser console logs & stack trace', completed: false },
        { id: 'st-3', title: 'Patch root cause in component state', completed: false },
        { id: 'st-4', title: 'Verify fix with automated regression test', completed: false }
      ];
    }

    // Default intelligent subtask generator
    return [
      { id: 'st-1', title: `Define specifications for "${taskTitle}"`, completed: true },
      { id: 'st-2', title: 'Implement core functionality & UI elements', completed: false },
      { id: 'st-3', title: 'Review & optimize performance edge cases', completed: false },
      { id: 'st-4', title: 'Deploy and test in staging environment', completed: false }
    ];
  },

  // Smart Priority & Estimate Predictor
  predictMeta: (taskTitle) => {
    const title = taskTitle.toLowerCase();
    let priority = 'medium';
    let category = 'feature';
    let estimatedHours = 4;
    let matrixQuadrant = 'schedule';

    if (title.includes('critical') || title.includes('bug') || title.includes('crash') || title.includes('urgent')) {
      priority = 'critical';
      category = 'bug';
      estimatedHours = 2;
      matrixQuadrant = 'do_first';
    } else if (title.includes('research') || title.includes('plan') || title.includes('architecture')) {
      priority = 'high';
      category = 'research';
      estimatedHours = 6;
      matrixQuadrant = 'do_first';
    } else if (title.includes('design') || title.includes('style') || title.includes('logo')) {
      priority = 'medium';
      category = 'design';
      estimatedHours = 5;
      matrixQuadrant = 'schedule';
    } else if (title.includes('marketing') || title.includes('email') || title.includes('social')) {
      priority = 'low';
      category = 'marketing';
      estimatedHours = 3;
      matrixQuadrant = 'delegate';
    }

    return { priority, category, estimatedHours, matrixQuadrant };
  },

  // AI Workspace Bottleneck & Productivity Advisor
  analyzeWorkspace: (tasks) => {
    const total = tasks.length;
    if (total === 0) return "Workspace is empty. Create a task or goal to begin!";

    const done = tasks.filter(t => t.status === 'done').length;
    const highPriorityCount = tasks.filter(t => (t.priority === 'high' || t.priority === 'critical') && t.status !== 'done').length;
    const overdueCount = tasks.filter(t => t.dueDate && new Date(t.dueDate) < new Date() && t.status !== 'done').length;
    const backlogCount = tasks.filter(t => t.status === 'backlog').length;

    let advice = [];
    if (overdueCount > 0) {
      advice.push(`⚠️ You have ${overdueCount} overdue task(s). Recommend addressing these before starting new features.`);
    }
    if (highPriorityCount > 2) {
      advice.push(`🔥 ${highPriorityCount} critical/high priority items pending. Consider moving lower priority tasks to the Backlog.`);
    }
    if (backlogCount > total * 0.4) {
      advice.push(`💡 Your backlog is over 40% of total tasks. Run an AI pruning session to consolidate goals.`);
    }
    if (done / total >= 0.7) {
      advice.push(`🎉 Outstanding velocity! Over 70% of project milestones completed.`);
    }

    if (advice.length === 0) {
      advice.push("✨ Workspace health is optimal. Velocity and focus are in perfect equilibrium!");
    }

    return advice.join(' ');
  }
};
