import React from 'react';
import { Icon } from './Icons';

export const EisenhowerMatrix = ({ tasks, onUpdateTaskQuadrant, onOpenTaskModal, onQuickAddTaskQuadrant }) => {
  const quadrants = [
    {
      id: 'do_first',
      title: '1. Do First',
      subtitle: 'Urgent & Important (Critical Deadlines)',
      color: '#ef4444',
      bg: 'var(--quad-do)',
      border: 'var(--quad-do-border)'
    },
    {
      id: 'schedule',
      title: '2. Schedule',
      subtitle: 'Important & Not Urgent (Strategic Goals)',
      color: '#3b82f6',
      bg: 'var(--quad-schedule)',
      border: 'var(--quad-schedule-border)'
    },
    {
      id: 'delegate',
      title: '3. Delegate',
      subtitle: 'Urgent & Not Important (Interruption / Admin)',
      color: '#f59e0b',
      bg: 'var(--quad-delegate)',
      border: 'var(--quad-delegate-border)'
    },
    {
      id: 'eliminate',
      title: '4. Eliminate',
      subtitle: 'Neither Urgent nor Important (Low Value)',
      color: '#64748b',
      bg: 'var(--quad-eliminate)',
      border: 'var(--quad-eliminate-border)'
    }
  ];

  const handleDragStart = (e, taskId) => {
    e.dataTransfer.setData('text/plain', taskId);
  };

  const handleDragOver = (e) => {
    e.preventDefault();
  };

  const handleDrop = (e, targetQuadrant) => {
    e.preventDefault();
    const taskId = e.dataTransfer.getData('text/plain');
    if (taskId) {
      onUpdateTaskQuadrant(taskId, targetQuadrant);
    }
  };

  return (
    <div style={{ padding: '24px', display: 'flex', flexDirection: 'column', gap: '20px', height: 'calc(100vh - 120px)' }}>
      {/* Header */}
      <div className="glass-panel" style={{ padding: '14px 20px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
          <Icon name="Matrix" size={20} color="var(--accent-primary)" />
          <div>
            <h2 style={{ fontSize: '1.1rem', fontWeight: 700 }}>Eisenhower Priority Matrix</h2>
            <p style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Drag and drop tasks into quadrants to prioritize effectively.</p>
          </div>
        </div>
      </div>

      {/* 2x2 Quadrants Grid */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gridTemplateRows: '1fr 1fr', gap: '16px', flex: 1 }}>
        {quadrants.map(quad => {
          const quadTasks = tasks.filter(t => (t.matrixQuadrant || 'schedule') === quad.id);

          return (
            <div
              key={quad.id}
              onDragOver={handleDragOver}
              onDrop={(e) => handleDrop(e, quad.id)}
              style={{
                background: quad.bg,
                border: `1px solid ${quad.border}`,
                borderRadius: 'var(--radius-xl)',
                padding: '16px',
                display: 'flex',
                flexDirection: 'column',
                gap: '12px',
                overflow: 'hidden'
              }}
            >
              {/* Quadrant Title */}
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <div>
                  <h3 style={{ fontSize: '1rem', fontWeight: 800, color: quad.color }}>{quad.title}</h3>
                  <span style={{ fontSize: '0.725rem', color: 'var(--text-muted)', fontWeight: 600 }}>{quad.subtitle}</span>
                </div>

                <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                  <span style={{ background: 'rgba(0,0,0,0.3)', padding: '2px 8px', borderRadius: '12px', fontSize: '0.75rem', fontWeight: 700, color: quad.color }}>
                    {quadTasks.length} tasks
                  </span>
                  <button
                    onClick={() => {
                      const title = prompt(`Quick add task to ${quad.title}:`);
                      if (title && title.trim()) {
                        onQuickAddTaskQuadrant(title.trim(), quad.id);
                      }
                    }}
                    className="btn btn-outline btn-sm"
                    style={{ padding: '4px 8px' }}
                  >
                    +
                  </button>
                </div>
              </div>

              {/* Tasks List */}
              <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', overflowY: 'auto', flex: 1, paddingRight: '4px' }}>
                {quadTasks.length === 0 ? (
                  <div style={{ textAlign: 'center', padding: '20px', color: 'var(--text-muted)', fontSize: '0.8rem', fontStyle: 'italic' }}>
                    Drag tasks here
                  </div>
                ) : (
                  quadTasks.map(task => (
                    <div
                      key={task.id}
                      draggable
                      onDragStart={(e) => handleDragStart(e, task.id)}
                      onClick={() => onOpenTaskModal(task)}
                      className="glass-panel"
                      style={{
                        padding: '12px',
                        cursor: 'grab',
                        background: 'var(--bg-card)',
                        border: '1px solid var(--border-color)',
                        borderRadius: 'var(--radius-md)',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'space-between',
                        gap: '10px'
                      }}
                    >
                      <div style={{ display: 'flex', flexDirection: 'column', gap: '2px' }}>
                        <span style={{ fontSize: '0.875rem', fontWeight: 600, color: 'var(--text-primary)' }}>
                          {task.title}
                        </span>
                        <span style={{ fontSize: '0.7rem', color: 'var(--text-muted)' }}>
                          Status: {task.status.replace('_', ' ')}
                        </span>
                      </div>
                      <span className={`badge badge-${task.priority}`} style={{ fontSize: '0.65rem' }}>
                        {task.priority}
                      </span>
                    </div>
                  ))
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
