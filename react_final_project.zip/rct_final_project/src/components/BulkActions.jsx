export default function BulkActions({ selectedCount, onDeleteSelected, onCompleteSelected, onClearSelection }) {
  if (selectedCount === 0) return null

  return (
    <div className="bulk-actions">
      <span className="bulk-count">{selectedCount} selected</span>
      <button className="btn btn-primary btn-small" onClick={onCompleteSelected}>
        Mark Complete
      </button>
      <button className="btn btn-danger btn-small" onClick={onDeleteSelected}>
        Delete Selected
      </button>
      <button className="btn btn-ghost btn-small" onClick={onClearSelection}>
        Clear Selection
      </button>
    </div>
  )
}
