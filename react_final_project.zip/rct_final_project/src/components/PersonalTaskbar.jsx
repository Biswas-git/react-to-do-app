import React, { useState } from 'react';
import { Icon } from './Icons';
import { soundFx } from '../utils/audio';

export const PersonalTaskbar = ({
  tasks = [],
  activeView,
  onSelectView,
  onQuickAddTask,
  onOpenNewTaskModal,
  onOpenAiModal,
  onOpenCommandPalette
}) => {
  const [taskTitle, setTaskTitle] = useState('');
  const [priority, setPriority] = useState('medium');
  const [category, setCategory] = useState('personal');
  const [isMinimized, setIsMinimized] = useState(false);
  const [isExpandedQuickAdd, setIsExpandedQuickAdd] = useState(false);

  // Compute task statistics
  const totalTasks = tasks.length;
  const completedTasks = tasks.filter(t => t.status === 'done').length;
  const inProgressTasks = tasks.filter(t => t.status === 'in-progress').length;
  const progressPercentage = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0;

  const handleFormSubmit = (e) => {
    e.preventDefault();
    if (!taskTitle.trim()) return;

    onQuickAddTask(taskTitle.trim(), 'todo', priority, category);
    soundFx.playSuccess();
    setTaskTitle('');
    setIsExpandedQuickAdd(false);
  };

  const navItems = [
    { id: 'kanban', label: 'Board', icon: 'Kanban' },
    { id: 'canvas', label: 'Canvas', icon: 'Canvas' },
    { id: 'gantt', label: 'Gantt', icon: 'Gantt' },
    { id: 'matrix', label: 'Matrix', icon: 'Matrix' },
    { id: 'calendar', label: 'Calendar', icon: 'Calendar' },
    { id: 'analytics', label: 'Analytics', icon: 'Analytics' },
    { id: 'focus', label: 'Focus', icon: 'Focus' },
    { id: 'automations', label: 'Rules', icon: 'Automation' }
  ];

  if (isMinimized) {
    return (
      <div style={{
        position: 'fixed',
        bottom: '20px',
        left: '50%',
        transform: 'translateX(-50%)',
        zIndex: 9999,
        background: 'rgba(15, 23, 42, 0.85)',
        backdropFilter: 'blur(16px)',
        border: '1px solid rgba(99, 102, 241, 0.3)',
        borderRadius: '30px',
        padding: '6px 16px',
        display: 'flex',
        alignItems: 'center',
        gap: '12px',
        boxShadow: '0 10px 25px rgba(0, 0, 0, 0.5), 0 0 15px rgba(99, 102, 241, 0.3)',
        transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)'
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
          <div style={{
            width: '24px',
            height: '24px',
            borderRadius: '50%',
            background: 'linear-gradient(135deg, #6366f1, #a855f7)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            color: '#fff'
          }}>
            <Icon name="ShieldCheck" size={14} color="#fff" />
          </div>
          <span style={{ fontSize: '0.85rem', fontWeight: 700, color: '#f8fafc', whiteSpace: 'nowrap' }}>
            Personal Taskbar
          </span>
          <span style={{
            fontSize: '0.75rem',
            fontWeight: 700,
            background: 'rgba(99, 102, 241, 0.2)',
            color: '#a5b4fc',
            padding: '2px 8px',
            borderRadius: '12px',
            border: '1px solid rgba(99, 102, 241, 0.3)'
          }}>
            {completedTasks}/{totalTasks} Done ({progressPercentage}%)
          </span>
        </div>

        <button
          onClick={() => { soundFx.playClick(); setIsMinimized(false); }}
          style={{
            background: 'rgba(255, 255, 255, 0.08)',
            border: 'none',
            borderRadius: '50%',
            width: '28px',
            height: '28px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            color: '#e2e8f0',
            cursor: 'pointer',
            transition: 'background 0.2s'
          }}
          title="Expand Personal Taskbar"
        >
          <Icon name="ChevronUp" size={16} />
        </button>
      </div>
    );
  }

  return (
    <div style={{
      position: 'fixed',
      bottom: '16px',
      left: '50%',
      transform: 'translateX(-50%)',
      zIndex: 9999,
      maxWidth: '96vw',
      width: 'auto',
      transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)'
    }}>
      <div style={{
        background: 'rgba(15, 23, 42, 0.88)',
        backdropFilter: 'blur(20px)',
        WebkitBackdropFilter: 'blur(20px)',
        border: '1px solid rgba(139, 92, 246, 0.3)',
        borderRadius: '20px',
        padding: '10px 16px',
        display: 'flex',
        flexDirection: 'column',
        gap: '10px',
        boxShadow: '0 20px 50px rgba(0, 0, 0, 0.6), 0 0 30px rgba(99, 102, 241, 0.25), inset 0 1px 0 rgba(255, 255, 255, 0.1)'
      }}>
        {/* Main Dock Header Bar */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '14px', flexWrap: 'nowrap' }}>
          
          {/* Brand & Mini Progress */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
            <div style={{
              width: '32px',
              height: '32px',
              borderRadius: '10px',
              background: 'linear-gradient(135deg, #6366f1 0%, #a855f7 50%, #ec4899 100%)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              boxShadow: '0 0 12px rgba(99, 102, 241, 0.5)'
            }}>
              <Icon name="ShieldCheck" size={18} color="#fff" />
            </div>

            <div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <span style={{ fontSize: '0.85rem', fontWeight: 800, color: '#ffffff', letterSpacing: '-0.01em' }}>
                  Personal Taskbar
                </span>
                <span style={{
                  fontSize: '0.7rem',
                  fontWeight: 700,
                  color: progressPercentage === 100 ? '#4ade80' : '#c084fc',
                  background: 'rgba(139, 92, 246, 0.15)',
                  padding: '1px 7px',
                  borderRadius: '10px',
                  border: '1px solid rgba(139, 92, 246, 0.3)'
                }}>
                  {completedTasks}/{totalTasks} Done
                </span>
              </div>
              
              {/* Progress track */}
              <div style={{
                width: '120px',
                height: '4px',
                background: 'rgba(255, 255, 255, 0.1)',
                borderRadius: '2px',
                marginTop: '4px',
                overflow: 'hidden'
              }}>
                <div style={{
                  width: `${progressPercentage}%`,
                  height: '100%',
                  background: 'linear-gradient(90deg, #6366f1, #ec4899)',
                  borderRadius: '2px',
                  transition: 'width 0.3s ease'
                }} />
              </div>
            </div>
          </div>

          <div style={{ width: '1px', height: '24px', background: 'rgba(255, 255, 255, 0.12)' }} />

          {/* Quick Task Creation Input */}
          <form onSubmit={handleFormSubmit} style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <div style={{ position: 'relative', display: 'flex', alignItems: 'center' }}>
              <input
                type="text"
                value={taskTitle}
                onChange={(e) => setTaskTitle(e.target.value)}
                placeholder="⚡ Quick task..."
                style={{
                  background: 'rgba(255, 255, 255, 0.06)',
                  border: '1px solid rgba(255, 255, 255, 0.15)',
                  borderRadius: '12px',
                  padding: '7px 12px',
                  fontSize: '0.85rem',
                  color: '#f8fafc',
                  width: '200px',
                  outline: 'none',
                  transition: 'all 0.2s ease'
                }}
                onFocus={(e) => {
                  e.target.style.borderColor = 'var(--accent-primary)';
                  e.target.style.background = 'rgba(255, 255, 255, 0.1)';
                }}
                onBlur={(e) => {
                  e.target.style.borderColor = 'rgba(255, 255, 255, 0.15)';
                  e.target.style.background = 'rgba(255, 255, 255, 0.06)';
                }}
              />
            </div>

            <button
              type="submit"
              disabled={!taskTitle.trim()}
              className="btn btn-primary btn-sm"
              style={{
                borderRadius: '10px',
                padding: '7px 12px',
                fontSize: '0.8rem',
                opacity: taskTitle.trim() ? 1 : 0.6
              }}
              title="Add task immediately"
            >
              <Icon name="Plus" size={14} />
              <span>Add</span>
            </button>
          </form>

          <div style={{ width: '1px', height: '24px', background: 'rgba(255, 255, 255, 0.12)' }} />

          {/* Dock Views Shortcuts */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '3px' }}>
            {navItems.map(item => {
              const isActive = activeView === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => { soundFx.playClick(); onSelectView(item.id); }}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    gap: '6px',
                    padding: '6px 10px',
                    borderRadius: '10px',
                    background: isActive ? 'rgba(99, 102, 241, 0.25)' : 'transparent',
                    border: isActive ? '1px solid rgba(99, 102, 241, 0.5)' : '1px solid transparent',
                    color: isActive ? '#a5b4fc' : '#94a3b8',
                    fontSize: '0.8rem',
                    fontWeight: 600,
                    cursor: 'pointer',
                    transition: 'all 0.15s ease'
                  }}
                  title={`Switch to ${item.label} view`}
                >
                  <Icon name={item.icon} size={15} color={isActive ? '#a5b4fc' : '#94a3b8'} />
                  <span className="taskbar-view-label">{item.label}</span>
                </button>
              );
            })}
          </div>

          <div style={{ width: '1px', height: '24px', background: 'rgba(255, 255, 255, 0.12)' }} />

          {/* Special Quick Actions */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
            <button
              onClick={() => { soundFx.playClick(); onOpenAiModal(); }}
              style={{
                background: 'rgba(168, 85, 247, 0.15)',
                border: '1px solid rgba(168, 85, 247, 0.3)',
                borderRadius: '10px',
                padding: '6px 10px',
                color: '#c084fc',
                fontSize: '0.8rem',
                fontWeight: 600,
                display: 'flex',
                alignItems: 'center',
                gap: '5px',
                cursor: 'pointer'
              }}
              title="Open AI Copilot"
            >
              <Icon name="Sparkles" size={14} color="#c084fc" />
              <span>AI</span>
            </button>

            <button
              onClick={() => { soundFx.playClick(); onOpenCommandPalette(); }}
              style={{
                background: 'rgba(255, 255, 255, 0.06)',
                border: '1px solid rgba(255, 255, 255, 0.12)',
                borderRadius: '10px',
                padding: '6px 10px',
                color: '#e2e8f0',
                fontSize: '0.8rem',
                fontWeight: 600,
                display: 'flex',
                alignItems: 'center',
                gap: '5px',
                cursor: 'pointer'
              }}
              title="Search & Commands (Ctrl+K)"
            >
              <Icon name="Search" size={14} />
            </button>

            {/* Minimize Taskbar toggle */}
            <button
              onClick={() => { soundFx.playClick(); setIsMinimized(true); }}
              style={{
                background: 'rgba(255, 255, 255, 0.06)',
                border: '1px solid rgba(255, 255, 255, 0.12)',
                borderRadius: '50%',
                width: '28px',
                height: '28px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                color: '#94a3b8',
                cursor: 'pointer',
                marginLeft: '4px'
              }}
              title="Minimize Personal Taskbar"
            >
              <Icon name="ChevronDown" size={16} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
