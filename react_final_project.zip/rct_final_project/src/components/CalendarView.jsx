import React, { useState } from 'react';
import { Icon } from './Icons';

export const CalendarView = ({ tasks, onOpenTaskModal, onQuickAddTaskAtDate }) => {
  const [currentDate, setCurrentDate] = useState(new Date());

  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();

  const monthNames = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];

  // Calculate days in month & starting weekday offset
  const firstDayOfMonth = new Date(year, month, 1).getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();

  const handlePrevMonth = () => {
    setCurrentDate(new Date(year, month - 1, 1));
  };

  const handleNextMonth = () => {
    setCurrentDate(new Date(year, month + 1, 1));
  };

  // Build grid calendar days array
  const calendarCells = [];
  for (let i = 0; i < firstDayOfMonth; i++) {
    calendarCells.push(null);
  }
  for (let day = 1; day <= daysInMonth; day++) {
    calendarCells.push(day);
  }

  const formatDayString = (day) => {
    const d = new Date(year, month, day);
    return d.toISOString().split('T')[0];
  };

  return (
    <div style={{ padding: '24px', display: 'flex', flexDirection: 'column', gap: '20px', height: 'calc(100vh - 120px)' }}>
      {/* Calendar Bar */}
      <div className="glass-panel" style={{ padding: '14px 20px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
          <Icon name="Calendar" size={20} color="var(--accent-primary)" />
          <h2 style={{ fontSize: '1.1rem', fontWeight: 700 }}>
            {monthNames[month]} {year}
          </h2>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
          <button onClick={handlePrevMonth} className="btn btn-secondary btn-sm">
            &larr; Prev Month
          </button>
          <button onClick={() => setCurrentDate(new Date())} className="btn btn-outline btn-sm">
            Today
          </button>
          <button onClick={handleNextMonth} className="btn btn-secondary btn-sm">
            Next Month &rarr;
          </button>
        </div>
      </div>

      {/* Monthly Grid */}
      <div className="glass-panel" style={{ padding: '20px', flex: 1, display: 'flex', flexDirection: 'column' }}>
        {/* Days of week header */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)', gap: '8px', marginBottom: '10px', textAlign: 'center' }}>
          {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((dayName, idx) => (
            <div key={idx} style={{ fontSize: '0.8rem', fontWeight: 700, color: 'var(--text-secondary)' }}>
              {dayName}
            </div>
          ))}
        </div>

        {/* Days Grid */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)', gap: '8px', flex: 1, overflowY: 'auto' }}>
          {calendarCells.map((day, index) => {
            if (day === null) {
              return <div key={`empty-${index}`} style={{ background: 'transparent' }} />;
            }

            const dateStr = formatDayString(day);
            const isToday = new Date().toISOString().split('T')[0] === dateStr;
            const dayTasks = tasks.filter(t => t.dueDate === dateStr);

            return (
              <div
                key={`day-${day}`}
                onClick={() => {
                  const title = prompt(`Add new task due on ${dateStr}:`);
                  if (title && title.trim()) {
                    onQuickAddTaskAtDate(title.trim(), dateStr);
                  }
                }}
                className="glass-panel"
                style={{
                  background: isToday ? 'rgba(99, 102, 241, 0.12)' : 'var(--bg-card)',
                  border: isToday ? '1px solid var(--accent-primary)' : '1px solid var(--border-color)',
                  borderRadius: 'var(--radius-md)',
                  padding: '8px',
                  display: 'flex',
                  flexDirection: 'column',
                  gap: '6px',
                  cursor: 'pointer',
                  minHeight: '85px'
                }}
              >
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                  <span style={{
                    fontSize: '0.85rem',
                    fontWeight: isToday ? 800 : 600,
                    color: isToday ? 'var(--accent-primary)' : 'var(--text-primary)'
                  }}>
                    {day}
                  </span>
                  {dayTasks.length > 0 && (
                    <span style={{ fontSize: '0.65rem', background: 'var(--accent-purple)', padding: '1px 6px', borderRadius: '10px', color: '#fff', fontWeight: 700 }}>
                      {dayTasks.length}
                    </span>
                  )}
                </div>

                {/* Day Tasks List */}
                <div style={{ display: 'flex', flexDirection: 'column', gap: '4px', overflowY: 'auto', flex: 1 }}>
                  {dayTasks.map(t => (
                    <div
                      key={t.id}
                      onClick={(e) => { e.stopPropagation(); onOpenTaskModal(t); }}
                      style={{
                        background: 'var(--bg-tertiary)',
                        padding: '3px 6px',
                        borderRadius: '4px',
                        fontSize: '0.725rem',
                        fontWeight: 600,
                        color: 'var(--text-primary)',
                        whiteSpace: 'nowrap',
                        overflow: 'hidden',
                        textOverflow: 'ellipsis',
                        borderLeft: `3px solid var(--priority-${t.priority})`
                      }}
                    >
                      {t.title}
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
