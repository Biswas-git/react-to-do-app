import React from 'react';
import { Icon } from './Icons';

export const Navbar = ({
  workspaces,
  activeWorkspaceId,
  onSelectWorkspace,
  activeView,
  onSelectView,
  onOpenNewTaskModal,
  onOpenAiModal,
  onOpenCommandPalette,
  theme,
  onToggleTheme,
  isMuted,
  onToggleSound,
  onExportData,
  onImportData
}) => {
  const views = [
    { id: 'kanban', label: 'Kanban Board', icon: 'Kanban' },
    { id: 'canvas', label: 'Spatial Canvas', icon: 'Canvas' },
    { id: 'gantt', label: 'Gantt Timeline', icon: 'Gantt' },
    { id: 'matrix', label: 'Eisenhower Matrix', icon: 'Matrix' },
    { id: 'calendar', label: 'Calendar', icon: 'Calendar' },
    { id: 'analytics', label: 'Analytics', icon: 'Analytics' },
    { id: 'focus', label: 'Focus Hub', icon: 'Focus' },
    { id: 'automations', label: 'Automations', icon: 'Automation' }
  ];

  return (
    <header style={{
      background: 'var(--bg-glass)',
      backdropFilter: 'blur(16px)',
      borderBottom: '1px solid var(--border-color)',
      position: 'sticky',
      top: 0,
      zIndex: 100
    }}>
      <div style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: '12px 24px',
        gap: '16px'
      }}>
        {/* Brand & Workspace Switcher */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
            <div className="logo-badge" style={{
              width: '38px',
              height: '38px',
              borderRadius: '12px',
              background: 'linear-gradient(135deg, #6366f1 0%, #a855f7 50%, #ec4899 100%)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              color: '#fff',
              boxShadow: '0 0 20px rgba(99, 102, 241, 0.5), inset 0 1px 0 rgba(255, 255, 255, 0.4)',
              transition: 'transform 0.2s ease, box-shadow 0.2s ease',
              cursor: 'pointer'
            }}>
              <Icon name="ShieldCheck" size={22} color="#ffffff" />
            </div>
            <div>
              <h1 style={{ fontSize: '1.2rem', fontWeight: 800, letterSpacing: '-0.02em', background: 'linear-gradient(90deg, #ffffff, #c7d2fe, #e0e7ff)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', margin: 0, lineHeight: 1.1 }}>
                Personal Taskbar
              </h1>
              <span style={{ fontSize: '0.65rem', color: 'var(--text-muted)', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.08em', display: 'block', marginTop: '2px' }}>
                Smart Task & Productivity Studio
              </span>
            </div>
          </div>

          <div style={{ width: '1px', height: '24px', background: 'var(--border-color)' }} />

          {/* Workspace Select Dropdown */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)', fontWeight: 600 }}>Space:</span>
            <select
              value={activeWorkspaceId}
              onChange={(e) => onSelectWorkspace(e.target.value)}
              className="input-field"
              style={{
                width: 'auto',
                padding: '6px 12px',
                fontSize: '0.85rem',
                fontWeight: 600,
                background: 'var(--bg-tertiary)'
              }}
            >
              {workspaces.map(ws => (
                <option key={ws.id} value={ws.id}>
                  {ws.name}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Global Action Buttons */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
          <button
            onClick={onOpenCommandPalette}
            className="btn btn-secondary btn-sm"
            style={{ display: 'flex', alignItems: 'center', gap: '8px', padding: '6px 12px' }}
            title="Command Palette (Ctrl + K)"
          >
            <Icon name="Search" size={14} />
            <span>Search / Commands</span>
            <kbd style={{
              background: 'var(--bg-primary)',
              padding: '2px 6px',
              borderRadius: '4px',
              fontSize: '0.7rem',
              color: 'var(--text-muted)',
              border: '1px solid var(--border-color)'
            }}>Ctrl K</kbd>
          </button>

          <button
            onClick={onOpenAiModal}
            className="btn btn-secondary btn-sm"
            style={{
              borderColor: 'var(--accent-purple)',
              color: '#c084fc',
              background: 'rgba(139, 92, 246, 0.1)'
            }}
          >
            <Icon name="Sparkles" size={15} color="#c084fc" />
            <span>AI Copilot</span>
          </button>

          <button
            onClick={onOpenNewTaskModal}
            className="btn btn-primary btn-sm"
          >
            <Icon name="Plus" size={16} />
            <span>New Task</span>
          </button>

          <div style={{ width: '1px', height: '24px', background: 'var(--border-color)' }} />

          {/* Sound & Theme Controls */}
          <button
            onClick={onToggleSound}
            className="btn btn-outline btn-icon"
            title={isMuted ? "Unmute Sounds" : "Mute Sounds"}
          >
            <Icon name={isMuted ? "VolumeX" : "Volume"} size={16} />
          </button>

          <button
            onClick={onToggleTheme}
            className="btn btn-outline btn-icon"
            title={`Switch Theme (Current: ${theme})`}
          >
            <Icon name={theme === 'dark' ? 'Moon' : theme === 'cyberpunk' ? 'Zap' : 'Sun'} size={16} />
          </button>

          {/* Import/Export Data Dropdown */}
          <button
            onClick={onExportData}
            className="btn btn-outline btn-icon"
            title="Export JSON Workspace Backup"
          >
            <Icon name="Download" size={16} />
          </button>
        </div>
      </div>

      {/* Navigation View Tabs Bar */}
      <div style={{
        display: 'flex',
        alignItems: 'center',
        padding: '0 24px',
        gap: '4px',
        borderTop: '1px solid var(--border-color)',
        overflowX: 'auto'
      }}>
        {views.map(v => {
          const isActive = activeView === v.id;
          return (
            <button
              key={v.id}
              onClick={() => onSelectView(v.id)}
              style={{
                display: 'inline-flex',
                alignItems: 'center',
                gap: '8px',
                padding: '10px 16px',
                fontSize: '0.85rem',
                fontWeight: 600,
                color: isActive ? 'var(--accent-primary)' : 'var(--text-secondary)',
                background: 'transparent',
                border: 'none',
                borderBottom: isActive ? '2px solid var(--accent-primary)' : '2px solid transparent',
                cursor: 'pointer',
                transition: 'all 0.15s ease',
                whiteSpace: 'nowrap'
              }}
            >
              <Icon name={v.icon} size={16} color={isActive ? 'var(--accent-primary)' : 'var(--text-muted)'} />
              <span>{v.label}</span>
            </button>
          );
        })}
      </div>
    </header>
  );
};
