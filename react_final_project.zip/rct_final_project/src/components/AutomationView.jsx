import React, { useState } from 'react';
import { Icon } from './Icons';

export const AutomationView = ({ automations, onToggleAutomation, onAddAutomation }) => {
  const [showAddForm, setShowAddForm] = useState(false);
  const [name, setName] = useState('');
  const [trigger, setTrigger] = useState('Priority Changed to Critical');
  const [condition, setCondition] = useState('Status is not Done');
  const [action, setAction] = useState('Move to Eisenhower "Do First" Quadrant');

  const handleCreate = (e) => {
    e.preventDefault();
    if (name.trim()) {
      onAddAutomation({
        id: `auto-${Date.now()}`,
        name: name.trim(),
        trigger,
        condition,
        action,
        enabled: true,
        executions: 0
      });
      setName('');
      setShowAddForm(false);
    }
  };

  return (
    <div style={{ padding: '24px', display: 'flex', flexDirection: 'column', gap: '20px', height: 'calc(100vh - 120px)', overflowY: 'auto' }}>
      {/* Header */}
      <div className="glass-panel" style={{ padding: '14px 20px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
          <Icon name="Automation" size={20} color="var(--accent-primary)" />
          <div>
            <h2 style={{ fontSize: '1.1rem', fontWeight: 700 }}>Custom Workflow Automations</h2>
            <p style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Automate task routing, tag assignments, and status promotions.</p>
          </div>
        </div>

        <button onClick={() => setShowAddForm(!showAddForm)} className="btn btn-primary btn-sm">
          <Icon name="Plus" size={16} />
          <span>New Automation Rule</span>
        </button>
      </div>

      {/* Add New Rule Form Modal / Expandable */}
      {showAddForm && (
        <form onSubmit={handleCreate} className="glass-panel animate-fade-in" style={{ padding: '20px', display: 'flex', flexDirection: 'column', gap: '14px' }}>
          <h3 style={{ fontSize: '1rem', fontWeight: 700 }}>Configure Automation Trigger</h3>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
            <label style={{ fontSize: '0.8rem', color: 'var(--text-muted)', fontWeight: 600 }}>Rule Name:</label>
            <input
              type="text"
              placeholder="e.g. Auto-Promote Urgent Bugs to Backlog"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="input-field"
              required
            />
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '12px' }}>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
              <label style={{ fontSize: '0.8rem', color: 'var(--text-muted)', fontWeight: 600 }}>WHEN (Trigger):</label>
              <select value={trigger} onChange={(e) => setTrigger(e.target.value)} className="input-field">
                <option value="Priority Changed to Critical">Priority Changed to Critical</option>
                <option value="Subtasks hit 100%">Subtasks hit 100%</option>
                <option value="Due Date Passed">Due Date Passed</option>
                <option value="Status Changed to Done">Status Changed to Done</option>
              </select>
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
              <label style={{ fontSize: '0.8rem', color: 'var(--text-muted)', fontWeight: 600 }}>IF (Condition):</label>
              <select value={condition} onChange={(e) => setCondition(e.target.value)} className="input-field">
                <option value="Status is not Done">Status is not Done</option>
                <option value="Status is In Progress">Status is In Progress</option>
                <option value="Priority is High">Priority is High</option>
              </select>
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
              <label style={{ fontSize: '0.8rem', color: 'var(--text-muted)', fontWeight: 600 }}>THEN (Action):</label>
              <select value={action} onChange={(e) => setAction(e.target.value)} className="input-field">
                <option value="Move to Eisenhower 'Do First' Quadrant">Move to 'Do First' Quadrant</option>
                <option value="Set Task Status to Completed & Play Chime">Set Task Status to Completed</option>
                <option value="Add Tag 'Urgent' and Set Priority to High">Add Tag 'Urgent'</option>
              </select>
            </div>
          </div>

          <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '10px', marginTop: '10px' }}>
            <button type="button" onClick={() => setShowAddForm(false)} className="btn btn-secondary btn-sm">
              Cancel
            </button>
            <button type="submit" className="btn btn-primary btn-sm">
              Create Rule
            </button>
          </div>
        </form>
      )}

      {/* Rules List */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
        {automations.map(rule => (
          <div key={rule.id} className="glass-panel" style={{ padding: '16px 20px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '16px' }}>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '4px' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                <Icon name="Zap" size={16} color={rule.enabled ? 'var(--accent-primary)' : 'var(--text-muted)'} />
                <h3 style={{ fontSize: '0.95rem', fontWeight: 700, color: rule.enabled ? 'var(--text-primary)' : 'var(--text-muted)' }}>
                  {rule.name}
                </h3>
              </div>
              <p style={{ fontSize: '0.8rem', color: 'var(--text-secondary)' }}>
                <strong>WHEN:</strong> {rule.trigger} &nbsp;|&nbsp; <strong>IF:</strong> {rule.condition} &nbsp;|&nbsp; <strong>THEN:</strong> {rule.action}
              </p>
            </div>

            <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
              <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)', fontWeight: 600 }}>
                {rule.executions} Executions
              </span>

              <button
                onClick={() => onToggleAutomation(rule.id)}
                className={`btn btn-sm ${rule.enabled ? 'btn-primary' : 'btn-outline'}`}
              >
                {rule.enabled ? 'Active' : 'Disabled'}
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
