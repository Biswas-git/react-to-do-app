import React, { useState, useEffect } from 'react';
import { Icon } from './Icons';
import { soundFx } from '../utils/audio';

export const CommandPalette = ({
  isOpen,
  onClose,
  tasks,
  onSelectView,
  onOpenTaskModal,
  onToggleTheme,
  onOpenNewTaskModal,
  onOpenAiModal
}) => {
  const [query, setQuery] = useState('');

  useEffect(() => {
    const handleKeyDown = (e) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const actions = [
    { id: 'act-new-task', label: 'Create New Task', category: 'Action', icon: 'Plus', run: () => onOpenNewTaskModal() },
    { id: 'act-ai', label: 'Open AI Copilot Blueprint Generator', category: 'Action', icon: 'Sparkles', run: () => onOpenAiModal() },
    { id: 'act-theme', label: 'Toggle Color Theme (Dark / Cyber / Light)', category: 'Action', icon: 'Zap', run: () => onToggleTheme() },

    { id: 'view-kanban', label: 'Switch to Kanban View', category: 'Navigation', icon: 'Kanban', run: () => onSelectView('kanban') },
    { id: 'view-canvas', label: 'Switch to Spatial Canvas', category: 'Navigation', icon: 'Canvas', run: () => onSelectView('canvas') },
    { id: 'view-gantt', label: 'Switch to Gantt Timeline', category: 'Navigation', icon: 'Gantt', run: () => onSelectView('gantt') },
    { id: 'view-matrix', label: 'Switch to Eisenhower Matrix', category: 'Navigation', icon: 'Matrix', run: () => onSelectView('matrix') },
    { id: 'view-calendar', label: 'Switch to Calendar View', category: 'Navigation', icon: 'Calendar', run: () => onSelectView('calendar') },
    { id: 'view-analytics', label: 'Switch to Analytics Dashboard', category: 'Navigation', icon: 'Analytics', run: () => onSelectView('analytics') },
    { id: 'view-focus', label: 'Switch to Focus Hub (Pomodoro)', category: 'Navigation', icon: 'Focus', run: () => onSelectView('focus') }
  ];

  // Search filter
  const filteredActions = actions.filter(a => a.label.toLowerCase().includes(query.toLowerCase()));
  const filteredTasks = tasks.filter(t => t.title.toLowerCase().includes(query.toLowerCase())).slice(0, 5);

  const executeAction = (action) => {
    soundFx.playClick();
    action.run();
    onClose();
  };

  const executeTask = (task) => {
    soundFx.playClick();
    onOpenTaskModal(task);
    onClose();
  };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content animate-fade-in" onClick={(e) => e.stopPropagation()} style={{ maxWidth: '580px', borderRadius: '16px', overflow: 'hidden' }}>
        {/* Input Bar */}
        <div style={{ padding: '16px', borderBottom: '1px solid var(--border-color)', display: 'flex', alignItems: 'center', gap: '12px', background: 'var(--bg-card)' }}>
          <Icon name="Search" size={18} color="var(--accent-primary)" />
          <input
            type="text"
            placeholder="Type a command, search tasks, or switch views..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            autoFocus
            style={{
              width: '100%',
              background: 'transparent',
              border: 'none',
              outline: 'none',
              color: 'var(--text-primary)',
              fontFamily: 'var(--font-sans)',
              fontSize: '1rem',
              fontWeight: 500
            }}
          />
          <kbd style={{ background: 'var(--bg-tertiary)', padding: '2px 6px', borderRadius: '4px', fontSize: '0.7rem', color: 'var(--text-muted)' }}>
            ESC
          </kbd>
        </div>

        {/* Results List */}
        <div style={{ padding: '12px', maxHeight: '350px', overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: '8px' }}>
          {/* Action Commands */}
          {filteredActions.length > 0 && (
            <div>
              <div style={{ fontSize: '0.7rem', textTransform: 'uppercase', color: 'var(--text-muted)', fontWeight: 700, padding: '4px 8px', letterSpacing: '0.05em' }}>
                Commands & Shortcuts
              </div>
              {filteredActions.map(act => (
                <div
                  key={act.id}
                  onClick={() => executeAction(act)}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '10px',
                    padding: '10px 12px',
                    borderRadius: '8px',
                    cursor: 'pointer',
                    fontSize: '0.875rem',
                    fontWeight: 600,
                    color: 'var(--text-primary)',
                    transition: 'background 0.15s ease'
                  }}
                  onMouseEnter={(e) => e.currentTarget.style.background = 'var(--bg-tertiary)'}
                  onMouseLeave={(e) => e.currentTarget.style.background = 'transparent'}
                >
                  <Icon name={act.icon} size={16} color="var(--accent-primary)" />
                  <span>{act.label}</span>
                </div>
              ))}
            </div>
          )}

          {/* Task Results */}
          {filteredTasks.length > 0 && (
            <div style={{ marginTop: '8px' }}>
              <div style={{ fontSize: '0.7rem', textTransform: 'uppercase', color: 'var(--text-muted)', fontWeight: 700, padding: '4px 8px', letterSpacing: '0.05em' }}>
                Matching Tasks ({filteredTasks.length})
              </div>
              {filteredTasks.map(t => (
                <div
                  key={t.id}
                  onClick={() => executeTask(t)}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    padding: '10px 12px',
                    borderRadius: '8px',
                    cursor: 'pointer',
                    fontSize: '0.875rem',
                    fontWeight: 600,
                    color: 'var(--text-primary)',
                    transition: 'background 0.15s ease'
                  }}
                  onMouseEnter={(e) => e.currentTarget.style.background = 'var(--bg-tertiary)'}
                  onMouseLeave={(e) => e.currentTarget.style.background = 'transparent'}
                >
                  <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                    <span className={`badge badge-${t.priority}`} style={{ fontSize: '0.65rem' }}>{t.priority}</span>
                    <span>{t.title}</span>
                  </div>
                  <span style={{ fontSize: '0.7rem', color: 'var(--text-muted)' }}>{t.status.replace('_', ' ')}</span>
                </div>
              ))}
            </div>
          )}

          {filteredActions.length === 0 && filteredTasks.length === 0 && (
            <div style={{ textAlign: 'center', padding: '24px', color: 'var(--text-muted)', fontSize: '0.85rem' }}>
              No commands or tasks found matching "{query}"
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
