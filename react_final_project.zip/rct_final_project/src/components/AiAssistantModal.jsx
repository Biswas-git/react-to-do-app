import React, { useState } from 'react';
import { Icon } from './Icons';
import { soundFx } from '../utils/audio';

export const AiAssistantModal = ({ onClose, onBatchAddTasks }) => {
  const [promptInput, setPromptInput] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);

  const presets = [
    '🚀 Launch SaaS MVP Platform in 2 weeks',
    '🔒 Audit & Patch Security Vulnerabilities',
    '🎨 Redesign Mobile App UI/UX Design System',
    '⚡ Optimize Backend REST API & DB Queries'
  ];

  const handleGenerate = (goalText) => {
    const query = goalText || promptInput;
    if (!query.trim()) return;

    setIsGenerating(true);
    soundFx.playClick();

    setTimeout(() => {
      const q = query.toLowerCase();
      let generatedTasks = [];

      if (q.includes('saas') || q.includes('mvp') || q.includes('launch')) {
        generatedTasks = [
          {
            title: 'Setup Landing Page & Value Proposition',
            description: 'Build responsive landing page with CTA email signup form.',
            status: 'todo',
            priority: 'high',
            category: 'marketing',
            estimatedHours: 6
          },
          {
            title: 'Build Core Payment Checkout Integration',
            description: 'Integrate Stripe SDK for monthly & annual subscriptions.',
            status: 'in_progress',
            priority: 'critical',
            category: 'feature',
            estimatedHours: 10
          },
          {
            title: 'User Analytics & Onboarding Funnel',
            description: 'Add PostHog / Mixpanel tracking events for user activation.',
            status: 'backlog',
            priority: 'medium',
            category: 'research',
            estimatedHours: 4
          }
        ];
      } else if (q.includes('security') || q.includes('audit')) {
        generatedTasks = [
          {
            title: 'Audit NPM Dependencies for Known CVEs',
            description: 'Run npm audit and update vulnerable sub-packages.',
            status: 'todo',
            priority: 'critical',
            category: 'bug',
            estimatedHours: 3
          },
          {
            title: 'Implement Rate-Limiting Guard middleware',
            description: 'Prevent brute-force authentication attacks on /api/login.',
            status: 'in_progress',
            priority: 'high',
            category: 'feature',
            estimatedHours: 5
          }
        ];
      } else {
        generatedTasks = [
          {
            title: `Define Requirements for "${query}"`,
            description: `Analyze scope and technical constraints for ${query}.`,
            status: 'todo',
            priority: 'high',
            category: 'research',
            estimatedHours: 4
          },
          {
            title: `Implement Core Logic for "${query}"`,
            description: `Build functional prototype and unit tests.`,
            status: 'backlog',
            priority: 'medium',
            category: 'feature',
            estimatedHours: 8
          }
        ];
      }

      onBatchAddTasks(generatedTasks);
      soundFx.playSuccess();
      setIsGenerating(false);
      onClose();
    }, 800);
  };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content animate-fade-in" onClick={(e) => e.stopPropagation()} style={{ maxWidth: '560px' }}>
        <div style={{ padding: '20px', borderBottom: '1px solid var(--border-color)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
            <div style={{ width: '32px', height: '32px', borderRadius: '8px', background: 'linear-gradient(135deg, #8b5cf6, #ec4899)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff' }}>
              <Icon name="Sparkles" size={18} />
            </div>
            <div>
              <h2 style={{ fontSize: '1.1rem', fontWeight: 800 }}>Nexus AI Goal Architect</h2>
              <p style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Describe a goal or milestone to auto-generate a structured project plan.</p>
            </div>
          </div>
          <button onClick={onClose} className="btn btn-outline btn-icon">
            <Icon name="Close" size={16} />
          </button>
        </div>

        <div style={{ padding: '20px', display: 'flex', flexDirection: 'column', gap: '16px' }}>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
            <label style={{ fontSize: '0.8rem', color: 'var(--text-muted)', fontWeight: 700 }}>What is your goal or project vision?</label>
            <textarea
              placeholder="e.g., Build an AI image generation SaaS app with Stripe subscription..."
              value={promptInput}
              onChange={(e) => setPromptInput(e.target.value)}
              className="input-field"
              rows={3}
            />
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
            <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)', fontWeight: 600 }}>Quick Preset Blueprint Templates:</span>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
              {presets.map((preset, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => handleGenerate(preset)}
                  className="btn btn-outline btn-sm"
                  style={{ justifyContent: 'flex-start', textAlign: 'left', fontSize: '0.8rem' }}
                >
                  {preset}
                </button>
              ))}
            </div>
          </div>

          <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '10px', marginTop: '10px' }}>
            <button type="button" onClick={onClose} className="btn btn-secondary btn-sm">
              Cancel
            </button>
            <button
              type="button"
              onClick={() => handleGenerate()}
              disabled={isGenerating || !promptInput.trim()}
              className="btn btn-primary btn-sm"
            >
              <Icon name="Sparkles" size={16} />
              <span>{isGenerating ? 'Synthesizing...' : 'Generate Blueprint Tasks'}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
