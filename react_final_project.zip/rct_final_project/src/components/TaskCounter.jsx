export default function TaskCounter({ activeCount, completedCount, onClearCompleted }) {
  return (
    <div className="task-counter">
      <span className="counter-text">
        <strong>{activeCount}</strong> active &bull; <strong>{completedCount}</strong> completed
      </span>
      {completedCount > 0 && (
        <button className="btn btn-secondary btn-small" onClick={onClearCompleted}>
          Clear completed
        </button>
      )}
    </div>
  )
}
