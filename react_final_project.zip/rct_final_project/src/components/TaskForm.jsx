import { useState } from 'react'

const CATEGORIES = ['Work', 'Personal', 'Urgent', 'Study']
const PRIORITIES = ['Low', 'Medium', 'High']
const RECURRENCE_OPTIONS = ['None', 'Daily', 'Weekly', 'Monthly']
const LABEL_COLORS = ['#ef4444', '#f59e0b', '#22c55e', '#3b82f6', '#8b5cf6', '#ec4899']

export default function TaskForm({ onAdd, existingLabels }) {
  const [title, setTitle] = useState('')
  const [category, setCategory] = useState('Personal')
  const [priority, setPriority] = useState('Medium')
  const [dueDate, setDueDate] = useState('')
  const [notes, setNotes] = useState('')
  const [recurrence, setRecurrence] = useState('None')
  const [labels, setLabels] = useState([])
  const [newLabel, setNewLabel] = useState('')
  const [labelColor, setLabelColor] = useState('#3b82f6')
  const [isExpanded, setIsExpanded] = useState(false)

  const handleSubmit = (e) => {
    e.preventDefault()
    const trimmed = title.trim()
    if (!trimmed) return
    onAdd({
      title: trimmed,
      category,
      priority,
      dueDate: dueDate || null,
      notes: notes.trim() || null,
      recurrence,
      labels,
    })
    setTitle('')
    setCategory('Personal')
    setPriority('Medium')
    setDueDate('')
    setNotes('')
    setRecurrence('None')
    setLabels([])
    setNewLabel('')
    setIsExpanded(false)
  }

  const addLabel = () => {
    const trimmed = newLabel.trim()
    if (!trimmed) return
    if (labels.some((l) => l.name.toLowerCase() === trimmed.toLowerCase())) return
    setLabels((prev) => [...prev, { name: trimmed, color: labelColor }])
    setNewLabel('')
  }

  const removeLabel = (labelName) => {
    setLabels((prev) => prev.filter((l) => l.name !== labelName))
  }

  const handleLabelKeyDown = (e) => {
    if (e.key === 'Enter') {
      e.preventDefault()
      addLabel()
    }
  }

  return (
    <form className="task-form" onSubmit={handleSubmit}>
      <div className="form-row">
        <label htmlFor="task-title" className="visually-hidden">
          Task title
        </label>
        <input
          id="task-title"
          type="text"
          className="form-input"
          placeholder="What needs to be done?"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          onFocus={() => setIsExpanded(true)}
        />
      </div>

      <div className={`form-expandable ${isExpanded ? 'expanded' : ''}`}>
        <div className="form-row form-row-inline">
          <div className="form-field">
            <label htmlFor="task-category">Category</label>
            <select
              id="task-category"
              className="form-select"
              value={category}
              onChange={(e) => setCategory(e.target.value)}
            >
              {CATEGORIES.map((cat) => (
                <option key={cat} value={cat}>
                  {cat}
                </option>
              ))}
            </select>
          </div>
          <div className="form-field">
            <label htmlFor="task-priority">Priority</label>
            <select
              id="task-priority"
              className="form-select"
              value={priority}
              onChange={(e) => setPriority(e.target.value)}
            >
              {PRIORITIES.map((p) => (
                <option key={p} value={p}>
                  {p}
                </option>
              ))}
            </select>
          </div>
          <div className="form-field">
            <label htmlFor="task-due-date">Due date</label>
            <input
              id="task-due-date"
              type="date"
              className="form-input"
              value={dueDate}
              onChange={(e) => setDueDate(e.target.value)}
            />
          </div>
        </div>

        <div className="form-row form-row-inline">
          <div className="form-field">
            <label htmlFor="task-recurrence">Repeats</label>
            <select
              id="task-recurrence"
              className="form-select"
              value={recurrence}
              onChange={(e) => setRecurrence(e.target.value)}
            >
              {RECURRENCE_OPTIONS.map((r) => (
                <option key={r} value={r}>
                  {r}
                </option>
              ))}
            </select>
          </div>
          <div className="form-field form-field-labels">
            <label htmlFor="task-label">Labels</label>
            <div className="label-input-group">
              <input
                id="task-label"
                type="text"
                className="form-input label-input"
                placeholder="Add label..."
                value={newLabel}
                onChange={(e) => setNewLabel(e.target.value)}
                onKeyDown={handleLabelKeyDown}
                list="existing-labels"
              />
              <datalist id="existing-labels">
                {existingLabels.map((l) => (
                  <option key={l} value={l} />
                ))}
              </datalist>
              <input
                type="color"
                className="label-color-picker"
                value={labelColor}
                onChange={(e) => setLabelColor(e.target.value)}
                aria-label="Label color"
                title="Choose label color"
              />
              <button type="button" className="btn btn-secondary btn-small" onClick={addLabel}>
                Add
              </button>
            </div>
            {labels.length > 0 && (
              <div className="label-preview">
                {labels.map((label) => (
                  <span
                    key={label.name}
                    className="label-tag"
                    style={{ backgroundColor: label.color }}
                  >
                    {label.name}
                    <button
                      type="button"
                      className="label-remove"
                      onClick={() => removeLabel(label.name)}
                      aria-label={`Remove label ${label.name}`}
                    >
                      &times;
                    </button>
                  </span>
                ))}
              </div>
            )}
          </div>
        </div>

        <div className="form-row">
          <label htmlFor="task-notes" className="visually-hidden">
            Notes
          </label>
          <textarea
            id="task-notes"
            className="form-textarea"
            placeholder="Add notes or details..."
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            rows={2}
          />
        </div>
      </div>

      <div className="form-row form-actions-row">
        <button
          type="button"
          className="btn btn-ghost btn-small"
          onClick={() => setIsExpanded(!isExpanded)}
        >
          {isExpanded ? 'Less options' : 'More options'}
        </button>
        <button type="submit" className="btn btn-primary">
          + Add Task
        </button>
      </div>
    </form>
  )
}
