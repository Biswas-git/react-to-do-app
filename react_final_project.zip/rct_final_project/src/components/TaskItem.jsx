import { useState } from 'react'

export default function TaskItem({
  task,
  isEditing,
  onToggle,
  onDelete,
  onEdit,
  onStartEdit,
  onCancelEdit,
  isSelected,
  onSelect,
  selectionMode,
  onToggleSubtask,
  onAddSubtask,
}) {
  const [editText, setEditText] = useState(task.title)
  const [editNotes, setEditNotes] = useState(task.notes || '')
  const [showConfirmDelete, setShowConfirmDelete] = useState(false)
  const [showSubtasks, setShowSubtasks] = useState(false)
  const [newSubtask, setNewSubtask] = useState('')

  const handleSave = () => {
    const trimmed = editText.trim()
    if (!trimmed) return
    onEdit(task.id, trimmed, editNotes.trim() || null)
  }

  const handleCancel = () => {
    setEditText(task.title)
    setEditNotes(task.notes || '')
    onCancelEdit()
  }

  const isOverdue =
    !task.completed &&
    task.dueDate &&
    new Date(task.dueDate + 'T23:59:59') < new Date()

  const isDueToday = () => {
    if (!task.dueDate || task.completed) return false
    const today = new Date().toISOString().split('T')[0]
    return task.dueDate === today
  }

  const getDueDateLabel = () => {
    if (!task.dueDate) return null
    const date = new Date(task.dueDate + 'T00:00:00')
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })
  }

  const completedSubtasks = (task.subtasks || []).filter((s) => s.completed).length
  const totalSubtasks = (task.subtasks || []).length

  const handleAddSubtask = () => {
    const trimmed = newSubtask.trim()
    if (!trimmed) return
    onAddSubtask(task.id, trimmed)
    setNewSubtask('')
  }

  return (
    <li className={`task-item ${task.completed ? 'completed' : ''} priority-${task.priority.toLowerCase()} ${isSelected ? 'selected' : ''}`}>
      <div className="task-main">
        {selectionMode && (
          <input
            type="checkbox"
            className="task-select-checkbox"
            checked={isSelected}
            onChange={() => onSelect(task.id)}
            aria-label={`Select "${task.title}"`}
          />
        )}
        <button
          className={`task-checkbox ${task.completed ? 'checked' : ''}`}
          onClick={() => onToggle(task.id)}
          aria-label={`Mark "${task.title}" as ${task.completed ? 'incomplete' : 'complete'}`}
          role="checkbox"
          aria-checked={task.completed}
        >
          {task.completed && <span className="checkmark">&#10003;</span>}
        </button>

        {isEditing ? (
          <div className="edit-mode">
            <input
              type="text"
              className="edit-input"
              value={editText}
              onChange={(e) => setEditText(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') handleSave()
                if (e.key === 'Escape') handleCancel()
              }}
              autoFocus
              aria-label="Edit task title"
            />
            <textarea
              className="edit-textarea"
              value={editNotes}
              onChange={(e) => setEditNotes(e.target.value)}
              placeholder="Notes..."
              rows={2}
              aria-label="Edit task notes"
            />
            <div className="edit-actions">
              <button className="btn btn-primary btn-small" onClick={handleSave}>
                Save
              </button>
              <button className="btn btn-secondary btn-small" onClick={handleCancel}>
                Cancel
              </button>
            </div>
          </div>
        ) : (
          <div className="task-content">
            <div className="task-title-row">
              <span className="task-title">{task.title}</span>
              {task.recurrence !== 'None' && (
                <span className="recurrence-badge" title={`Repeats ${task.recurrence}`}>
                  &#128257; {task.recurrence}
                </span>
              )}
            </div>
            {task.notes && <p className="task-notes">{task.notes}</p>}
            <div className="task-meta">
              <span className={`badge badge-${task.category.toLowerCase()}`}>
                {task.category}
              </span>
              <span className={`priority-indicator priority-${task.priority.toLowerCase()}`}>
                {task.priority === 'High' ? "\u{1F534}" : task.priority === 'Medium' ? "\u{1F7E1}" : "\u{1F7E2}"}
                {task.priority}
              </span>
              {task.dueDate && (
                <span className={`due-date ${isOverdue ? 'overdue' : ''} ${isDueToday() ? 'due-today' : ''}`}>
                  {isOverdue ? "\u{26A0}\u{FE0F} Overdue: " : isDueToday() ? "\u{1F4C5} Today: " : "\u{1F4C5} Due: "}
                  {getDueDateLabel()}
                </span>
              )}
              {task.labels && task.labels.length > 0 && (
                <span className="task-labels">
                  {task.labels.map((label) => (
                    <span
                      key={label.name}
                      className="label-tag small"
                      style={{ backgroundColor: label.color }}
                    >
                      {label.name}
                    </span>
                  ))}
                </span>
              )}
            </div>
            {totalSubtasks > 0 && (
              <div className="subtask-progress">
                <div className="subtask-progress-bar">
                  <div
                    className="subtask-progress-fill"
                    style={{ width: `${(completedSubtasks / totalSubtasks) * 100}%` }}
                  />
                </div>
                <span className="subtask-count">{completedSubtasks}/{totalSubtasks}</span>
              </div>
            )}
          </div>
        )}
      </div>

      {!isEditing && (
        <div className="task-actions">
          {totalSubtasks > 0 && (
            <button
              className="btn btn-ghost btn-small"
              onClick={() => setShowSubtasks(!showSubtasks)}
              aria-label={`${showSubtasks ? 'Hide' : 'Show'} subtasks`}
              title="Toggle subtasks"
            >
              &#9776; {totalSubtasks}
            </button>
          )}
          <button
            className="btn btn-secondary btn-small"
            onClick={() => {
              setEditText(task.title)
              setEditNotes(task.notes || '')
              onStartEdit(task.id)
            }}
            aria-label={`Edit "${task.title}"`}
            title="Edit task"
          >
            &#9998;
          </button>
          {showConfirmDelete ? (
            <div className="confirm-delete">
              <button
                className="btn btn-danger btn-small"
                onClick={() => onDelete(task.id)}
                aria-label="Confirm delete"
              >
                Confirm
              </button>
              <button
                className="btn btn-ghost btn-small"
                onClick={() => setShowConfirmDelete(false)}
                aria-label="Cancel delete"
              >
                No
              </button>
            </div>
          ) : (
            <button
              className="btn btn-danger btn-small"
              onClick={() => setShowConfirmDelete(true)}
              aria-label={`Delete "${task.title}"`}
              title="Delete task"
            >
              &#128465;
            </button>
          )}
        </div>
      )}

      {showSubtasks && !isEditing && (
        <div className="subtask-section">
          <ul className="subtask-list">
            {(task.subtasks || []).map((subtask) => (
              <li key={subtask.id} className={`subtask-item ${subtask.completed ? 'completed' : ''}`}>
                <input
                  type="checkbox"
                  checked={subtask.completed}
                  onChange={() => onToggleSubtask(task.id, subtask.id)}
                  aria-label={`Mark subtask "${subtask.title}" as ${subtask.completed ? 'incomplete' : 'complete'}`}
                />
                <span className="subtask-title">{subtask.title}</span>
              </li>
            ))}
          </ul>
          <div className="subtask-add">
            <input
              type="text"
              className="form-input subtask-input"
              placeholder="Add subtask..."
              value={newSubtask}
              onChange={(e) => setNewSubtask(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') handleAddSubtask()
              }}
              aria-label="New subtask"
            />
            <button className="btn btn-primary btn-small" onClick={handleAddSubtask}>
              Add
            </button>
          </div>
        </div>
      )}
    </li>
  )
}
