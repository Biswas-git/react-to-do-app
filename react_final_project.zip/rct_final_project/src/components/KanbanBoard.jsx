import { useState } from 'react'

export default function KanbanBoard({ tasks, onToggle, onDelete, onEdit, onStartEdit, onCancelEdit, editingId }) {
  const [dragOverColumn, setDragOverColumn] = useState(null)

  const columns = [
    { id: 'active', title: 'Active', tasks: tasks.filter((t) => !t.completed) },
    { id: 'completed', title: 'Completed', tasks: tasks.filter((t) => t.completed) },
  ]

  const handleDragStart = (e, taskId) => {
    e.dataTransfer.setData('text/plain', taskId)
    e.dataTransfer.effectAllowed = 'move'
  }

  const handleDragOver = (e, columnId) => {
    e.preventDefault()
    e.dataTransfer.dropEffect = 'move'
    setDragOverColumn(columnId)
  }

  const handleDragLeave = () => {
    setDragOverColumn(null)
  }

  const handleDrop = (e, columnId) => {
    e.preventDefault()
    const taskId = e.dataTransfer.getData('text/plain')
    const task = tasks.find((t) => t.id === taskId)
    if (task) {
      if (columnId === 'completed' && !task.completed) {
        onToggle(taskId)
      } else if (columnId === 'active' && task.completed) {
        onToggle(taskId)
      }
    }
    setDragOverColumn(null)
  }

  return (
    <div className="kanban-board">
      {columns.map((column) => (
        <div
          key={column.id}
          className={`kanban-column ${dragOverColumn === column.id ? 'drag-over' : ''}`}
          onDragOver={(e) => handleDragOver(e, column.id)}
          onDragLeave={handleDragLeave}
          onDrop={(e) => handleDrop(e, column.id)}
        >
          <div className="kanban-column-header">
            <h3 className="kanban-column-title">{column.title}</h3>
            <span className="kanban-column-count">{column.tasks.length}</span>
          </div>
          <div className="kanban-column-body">
            {column.tasks.length === 0 && (
              <div className="kanban-empty">Drop tasks here</div>
            )}
            {column.tasks.map((task) => (
              <div
                key={task.id}
                className={`kanban-card priority-${task.priority.toLowerCase()} ${task.completed ? 'completed' : ''}`}
                draggable
                onDragStart={(e) => handleDragStart(e, task.id)}
              >
                <div className="kanban-card-header">
                  <span className="kanban-card-title">{task.title}</span>
                  <div className="kanban-card-actions">
                    <button
                      className="btn btn-ghost btn-small"
                      onClick={() => onStartEdit(task.id)}
                      aria-label={`Edit "${task.title}"`}
                    >
                      &#9998;
                    </button>
                    <button
                      className="btn btn-danger btn-small"
                      onClick={() => onDelete(task.id)}
                      aria-label={`Delete "${task.title}"`}
                    >
                      &#128465;
                    </button>
                  </div>
                </div>
                <div className="kanban-card-meta">
                  <span className={`badge badge-${task.category.toLowerCase()}`}>
                    {task.category}
                  </span>
                  <span className={`priority-indicator priority-${task.priority.toLowerCase()}`}>
                    {task.priority}
                  </span>
                  {task.dueDate && (
                    <span className={`due-date ${!task.completed && new Date(task.dueDate + 'T23:59:59') < new Date() ? 'overdue' : ''}`}>
                      {new Date(task.dueDate + 'T00:00:00').toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                    </span>
                  )}
                </div>
                {task.labels && task.labels.length > 0 && (
                  <div className="kanban-card-labels">
                    {task.labels.map((label) => (
                      <span
                        key={label.name}
                        className="label-tag small"
                        style={{ backgroundColor: label.color }}
                      >
                        {label.name}
                      </span>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  )
}
