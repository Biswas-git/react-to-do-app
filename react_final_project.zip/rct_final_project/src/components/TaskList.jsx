import TaskItem from './TaskItem.jsx'

export default function TaskList({
  tasks,
  editingId,
  onToggle,
  onDelete,
  onEdit,
  onStartEdit,
  onCancelEdit,
  hasAnyTasks,
  statusFilter,
  selectedTasks,
  onSelectTask,
  onSelectAll,
  selectionMode,
  onToggleSubtask,
  onAddSubtask,
}) {
  if (!hasAnyTasks) {
    return (
      <div className="empty-state">
        <div className="empty-icon">&#128221;</div>
        <p className="empty-title">No tasks yet</p>
        <p className="empty-subtitle">Add your first task above to get started!</p>
      </div>
    )
  }

  if (tasks.length === 0) {
    return (
      <div className="empty-state">
        <div className="empty-icon">&#128269;</div>
        <p className="empty-title">No matching tasks</p>
        <p className="empty-subtitle">
          {statusFilter === 'completed'
            ? 'No completed tasks yet. Keep going!'
            : statusFilter === 'active'
            ? 'All tasks are completed. Great job!'
            : 'Try adjusting your filters or search query.'}
        </p>
      </div>
    )
  }

  return (
    <div className="task-list-wrapper">
      {selectionMode && tasks.length > 0 && (
        <div className="select-all-bar">
          <label className="select-all-label">
            <input
              type="checkbox"
              checked={selectedTasks.size === tasks.length}
              onChange={onSelectAll}
              aria-label="Select all tasks"
            />
            Select all ({tasks.length})
          </label>
        </div>
      )}
      <ul className="task-list">
        {tasks.map((task) => (
          <TaskItem
            key={task.id}
            task={task}
            isEditing={editingId === task.id}
            onToggle={onToggle}
            onDelete={onDelete}
            onEdit={onEdit}
            onStartEdit={onStartEdit}
            onCancelEdit={onCancelEdit}
            isSelected={selectedTasks.has(task.id)}
            onSelect={onSelectTask}
            selectionMode={selectionMode}
            onToggleSubtask={onToggleSubtask}
            onAddSubtask={onAddSubtask}
          />
        ))}
      </ul>
    </div>
  )
}
