import React from 'react';
import { Icon } from './Icons';
import { aiAssistant } from '../utils/aiSimulator';

export const AnalyticsDashboard = ({ tasks }) => {
  const totalTasks = tasks.length;
  const completedTasks = tasks.filter(t => t.status === 'done').length;
  const inProgressTasks = tasks.filter(t => t.status === 'in_progress').length;
  const overdueTasks = tasks.filter(t => t.dueDate && new Date(t.dueDate) < new Date() && t.status !== 'done').length;

  const totalEstimated = tasks.reduce((sum, t) => sum + (t.estimatedHours || 0), 0);
  const totalLogged = tasks.reduce((sum, t) => sum + (t.loggedHours || 0), 0);

  const completionPct = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0;

  // Priorities count
  const prioritiesCount = {
    low: tasks.filter(t => t.priority === 'low').length,
    medium: tasks.filter(t => t.priority === 'medium').length,
    high: tasks.filter(t => t.priority === 'high').length,
    critical: tasks.filter(t => t.priority === 'critical').length
  };

  // Categories count
  const categoriesCount = {
    feature: tasks.filter(t => t.category === 'feature').length,
    bug: tasks.filter(t => t.category === 'bug').length,
    design: tasks.filter(t => t.category === 'design').length,
    research: tasks.filter(t => t.category === 'research').length,
    marketing: tasks.filter(t => t.category === 'marketing').length
  };

  const aiInsights = aiAssistant.analyzeWorkspace(tasks);

  return (
    <div style={{ padding: '24px', display: 'flex', flexDirection: 'column', gap: '20px', height: 'calc(100vh - 120px)', overflowY: 'auto' }}>
      {/* Header */}
      <div className="glass-panel" style={{ padding: '14px 20px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
          <Icon name="Analytics" size={20} color="var(--accent-primary)" />
          <div>
            <h2 style={{ fontSize: '1.1rem', fontWeight: 700 }}>Workspace Analytics & Productivity Intelligence</h2>
            <p style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Real-time metrics, time tracking, velocity, and AI bottleneck analysis.</p>
          </div>
        </div>
      </div>

      {/* KPI Cards Row */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '16px' }}>
        <div className="glass-panel" style={{ padding: '16px', display: 'flex', flexDirection: 'column', gap: '6px' }}>
          <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)', fontWeight: 600 }}>Completion Velocity</span>
          <div style={{ fontSize: '1.8rem', fontWeight: 800, color: 'var(--accent-primary)' }}>{completionPct}%</div>
          <span style={{ fontSize: '0.7rem', color: '#10b981' }}>{completedTasks} of {totalTasks} tasks done</span>
        </div>

        <div className="glass-panel" style={{ padding: '16px', display: 'flex', flexDirection: 'column', gap: '6px' }}>
          <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)', fontWeight: 600 }}>Effort Logged</span>
          <div style={{ fontSize: '1.8rem', fontWeight: 800, color: 'var(--accent-purple)' }}>{totalLogged}h / {totalEstimated}h</div>
          <span style={{ fontSize: '0.7rem', color: 'var(--text-secondary)' }}>Estimated vs actual time</span>
        </div>

        <div className="glass-panel" style={{ padding: '16px', display: 'flex', flexDirection: 'column', gap: '6px' }}>
          <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)', fontWeight: 600 }}>Active In-Flight</span>
          <div style={{ fontSize: '1.8rem', fontWeight: 800, color: '#3b82f6' }}>{inProgressTasks}</div>
          <span style={{ fontSize: '0.7rem', color: 'var(--text-secondary)' }}>Tasks currently in progress</span>
        </div>

        <div className="glass-panel" style={{ padding: '16px', display: 'flex', flexDirection: 'column', gap: '6px' }}>
          <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)', fontWeight: 600 }}>Overdue Items</span>
          <div style={{ fontSize: '1.8rem', fontWeight: 800, color: overdueTasks > 0 ? '#ef4444' : '#10b981' }}>{overdueTasks}</div>
          <span style={{ fontSize: '0.7rem', color: 'var(--text-secondary)' }}>Passed due date</span>
        </div>
      </div>

      {/* Charts Grid */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: '16px' }}>
        {/* Priority Breakdown Bar Chart */}
        <div className="glass-panel" style={{ padding: '20px', display: 'flex', flexDirection: 'column', gap: '14px' }}>
          <h3 style={{ fontSize: '0.95rem', fontWeight: 700 }}>Priority Distribution</h3>

          {Object.entries(prioritiesCount).map(([prio, count]) => {
            const maxVal = Math.max(...Object.values(prioritiesCount), 1);
            const pct = (count / maxVal) * 100;
            return (
              <div key={prio} style={{ display: 'flex', flexDirection: 'column', gap: '4px' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.75rem', fontWeight: 600 }}>
                  <span style={{ textTransform: 'capitalize' }}>{prio}</span>
                  <span>{count} tasks</span>
                </div>
                <div style={{ width: '100%', height: '8px', background: 'var(--bg-tertiary)', borderRadius: '4px', overflow: 'hidden' }}>
                  <div style={{ width: `${pct}%`, height: '100%', background: `var(--priority-${prio})`, borderRadius: '4px', transition: 'width 0.4s ease' }} />
                </div>
              </div>
            );
          })}
        </div>

        {/* Category Breakdown Bar Chart */}
        <div className="glass-panel" style={{ padding: '20px', display: 'flex', flexDirection: 'column', gap: '14px' }}>
          <h3 style={{ fontSize: '0.95rem', fontWeight: 700 }}>Category Distribution</h3>

          {Object.entries(categoriesCount).map(([cat, count]) => {
            const maxVal = Math.max(...Object.values(categoriesCount), 1);
            const pct = (count / maxVal) * 100;
            return (
              <div key={cat} style={{ display: 'flex', flexDirection: 'column', gap: '4px' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.75rem', fontWeight: 600 }}>
                  <span style={{ textTransform: 'capitalize' }}>{cat}</span>
                  <span>{count} tasks</span>
                </div>
                <div style={{ width: '100%', height: '8px', background: 'var(--bg-tertiary)', borderRadius: '4px', overflow: 'hidden' }}>
                  <div style={{ width: `${pct}%`, height: '100%', background: 'var(--accent-secondary)', borderRadius: '4px', transition: 'width 0.4s ease' }} />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* AI Intelligence Insights Box */}
      <div className="glass-panel" style={{ padding: '20px', background: 'rgba(139, 92, 246, 0.1)', borderColor: 'var(--accent-purple)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '8px' }}>
          <Icon name="Sparkles" size={20} color="#c084fc" />
          <h3 style={{ fontSize: '1rem', fontWeight: 700, color: '#c084fc' }}>AI Workspace Efficiency Advisor</h3>
        </div>
        <p style={{ fontSize: '0.875rem', color: 'var(--text-primary)', lineHeight: 1.5 }}>
          {aiInsights}
        </p>
      </div>
    </div>
  );
};
