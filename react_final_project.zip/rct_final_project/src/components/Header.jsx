export default function Header({ theme, onToggleTheme, onExport, onImport, onOpenPalette, viewMode, onViewModeChange }) {
  return (
    <header className="header">
      <div className="header-left">
        <h1 className="header-title">
          <span className="header-logo">
            <svg width="28" height="28" viewBox="0 0 24 24" fill="none" aria-hidden="true">
              <rect x="2" y="2" width="20" height="20" rx="5" fill="var(--accent-primary)" />
              <path d="M7 12.5l3.5 3.5L17 8.5" stroke="#fff" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </span>
          Personal Taskbar
        </h1>
        <p className="header-subtitle">Organize your day, your way</p>
      </div>
      <div className="header-actions">
        <div className="view-toggle" role="group" aria-label="View mode">
          <button
            className={`view-btn ${viewMode === 'list' ? 'active' : ''}`}
            onClick={() => onViewModeChange('list')}
            aria-label="List view"
            title="List view"
          >
            &#9776; List
          </button>
          <button
            className={`view-btn ${viewMode === 'board' ? 'active' : ''}`}
            onClick={() => onViewModeChange('board')}
            aria-label="Board view"
            title="Board view"
          >
            &#9638; Board
          </button>
          <button
            className={`view-btn ${viewMode === 'calendar' ? 'active' : ''}`}
            onClick={() => onViewModeChange('calendar')}
            aria-label="Calendar view"
            title="Calendar view"
          >
            &#128197; Calendar
          </button>
        </div>
        <button className="btn btn-icon" onClick={onOpenPalette} aria-label="Open command palette" title="Command palette (Ctrl+K)">
          {"\u2318"}K
        </button>
        <button className="btn btn-icon" onClick={onExport} aria-label="Export tasks" title="Export tasks">
          &#8681;
        </button>
        <button className="btn btn-icon" onClick={onImport} aria-label="Import tasks" title="Import tasks">
          &#8682;
        </button>
        <button
          className="btn btn-icon"
          onClick={onToggleTheme}
          aria-label={`Switch to ${theme === 'light' ? 'dark' : 'light'} mode`}
          title="Toggle theme"
        >
          {theme === 'light' ? '\u{1F319}' : '\u{2600}\u{FE0F}'}
        </button>
      </div>
    </header>
  )
}
