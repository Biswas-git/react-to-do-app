export default function StatsBar({ totalTasks, activeCount, completedCount, overdueCount, recurringCount }) {
  const completionPercent = totalTasks > 0 ? Math.round((completedCount / totalTasks) * 100) : 0

  return (
    <div className="stats-bar">
      <div className="stats-info">
        <div className="stats-numbers">
          <span className="stat-pill stat-total">{totalTasks} total</span>
          <span className="stat-pill stat-active">{activeCount} active</span>
          <span className="stat-pill stat-completed">{completedCount} done</span>
          {overdueCount > 0 && (
            <span className="stat-pill stat-overdue">{overdueCount} overdue</span>
          )}
          {recurringCount > 0 && (
            <span className="stat-pill stat-recurring">{recurringCount} recurring</span>
          )}
        </div>
        <div className="progress-bar" role="progressbar" aria-valuenow={completionPercent} aria-valuemin={0} aria-valuemax={100} aria-label="Task completion progress">
          <div className="progress-fill" style={{ width: `${completionPercent}%` }} />
        </div>
        <span className="progress-label">{completionPercent}% complete</span>
      </div>
    </div>
  )
}
