import React, { useState, useEffect } from 'react';
import { Icon } from './Icons';
import { soundFx } from '../utils/audio';

export const FocusHub = ({ tasks }) => {
  const [timerMode, setTimerMode] = useState('work'); // 'work' (25m), 'shortBreak' (5m), 'longBreak' (15m)
  const [timeLeft, setTimeLeft] = useState(25 * 60);
  const [isRunning, setIsRunning] = useState(false);
  const [sessionsCompleted, setSessionsCompleted] = useState(3);
  const [selectedTaskId, setSelectedTaskId] = useState('');
  const [ambientSound, setAmbientSound] = useState('none');

  const modeDurations = {
    work: 25 * 60,
    shortBreak: 5 * 60,
    longBreak: 15 * 60
  };

  useEffect(() => {
    let interval = null;
    if (isRunning && timeLeft > 0) {
      interval = setInterval(() => {
        setTimeLeft(t => t - 1);
      }, 1000);
    } else if (timeLeft === 0 && isRunning) {
      setIsRunning(false);
      soundFx.playTimerAlarm();
      if (timerMode === 'work') {
        setSessionsCompleted(s => s + 1);
        alert('🎉 Focus Session Completed! Time for a short break.');
        switchMode('shortBreak');
      } else {
        alert('Break completed! Ready to get back into focus mode?');
        switchMode('work');
      }
    }
    return () => clearInterval(interval);
  }, [isRunning, timeLeft, timerMode]);

  const switchMode = (mode) => {
    setTimerMode(mode);
    setTimeLeft(modeDurations[mode]);
    setIsRunning(false);
  };

  const toggleTimer = () => {
    if (!isRunning) {
      soundFx.playClick();
    }
    setIsRunning(!isRunning);
  };

  const resetTimer = () => {
    setIsRunning(false);
    setTimeLeft(modeDurations[timerMode]);
  };

  const handleAmbientChange = (e) => {
    const val = e.target.value;
    setAmbientSound(val);
    soundFx.playAmbient(val);
  };

  const formatTime = (seconds) => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const totalDuration = modeDurations[timerMode];
  const progressPct = ((totalDuration - timeLeft) / totalDuration) * 100;

  return (
    <div style={{ padding: '24px', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '24px', height: 'calc(100vh - 120px)', overflowY: 'auto' }}>
      {/* Header */}
      <div className="glass-panel" style={{ width: '100%', maxWidth: '600px', padding: '14px 20px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
          <Icon name="Focus" size={20} color="var(--accent-primary)" />
          <h2 style={{ fontSize: '1.1rem', fontWeight: 700 }}>Focus & Pomodoro Studio</h2>
        </div>
        <div style={{ fontSize: '0.8rem', color: '#10b981', fontWeight: 700 }}>
          ⚡ {sessionsCompleted} Sessions Done Today
        </div>
      </div>

      {/* Main Clock Panel */}
      <div className="glass-panel" style={{ width: '100%', maxWidth: '600px', padding: '36px 20px', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '24px' }}>
        {/* Mode Selector Tabs */}
        <div style={{ display: 'flex', gap: '8px', background: 'var(--bg-tertiary)', padding: '4px', borderRadius: 'var(--radius-md)' }}>
          <button
            onClick={() => switchMode('work')}
            className={`btn btn-sm ${timerMode === 'work' ? 'btn-primary' : 'btn-outline'}`}
          >
            Deep Focus (25m)
          </button>
          <button
            onClick={() => switchMode('shortBreak')}
            className={`btn btn-sm ${timerMode === 'shortBreak' ? 'btn-primary' : 'btn-outline'}`}
          >
            Short Break (5m)
          </button>
          <button
            onClick={() => switchMode('longBreak')}
            className={`btn btn-sm ${timerMode === 'longBreak' ? 'btn-primary' : 'btn-outline'}`}
          >
            Long Break (15m)
          </button>
        </div>

        {/* Circular Progress Display */}
        <div style={{ position: 'relative', width: '240px', height: '240px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <svg width="240" height="240" viewBox="0 0 240 240" style={{ transform: 'rotate(-90deg)' }}>
            <circle cx="120" cy="120" r="100" stroke="var(--bg-tertiary)" strokeWidth="12" fill="none" />
            <circle
              cx="120"
              cy="120"
              r="100"
              stroke="var(--accent-primary)"
              strokeWidth="12"
              fill="none"
              strokeDasharray="628"
              strokeDashoffset={628 - (628 * progressPct) / 100}
              strokeLinecap="round"
              style={{ transition: 'stroke-dashoffset 0.5s ease' }}
            />
          </svg>

          <div style={{ position: 'absolute', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '4px' }}>
            <span style={{ fontSize: '3rem', fontWeight: 800, fontFamily: 'var(--font-mono)', letterSpacing: '-0.04em' }}>
              {formatTime(timeLeft)}
            </span>
            <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)', textTransform: 'uppercase', fontWeight: 700, letterSpacing: '0.1em' }}>
              {timerMode.replace(/([A-Z])/g, ' $1')}
            </span>
          </div>
        </div>

        {/* Controls */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
          <button onClick={toggleTimer} className="btn btn-primary btn-lg" style={{ minWidth: '130px' }}>
            <Icon name={isRunning ? 'Pause' : 'Play'} size={18} />
            <span>{isRunning ? 'Pause' : 'Start Focus'}</span>
          </button>

          <button onClick={resetTimer} className="btn btn-secondary btn-icon" title="Reset Timer">
            <Icon name="Refresh" size={18} />
          </button>
        </div>

        {/* Active Task Selector */}
        <div style={{ width: '100%', display: 'flex', flexDirection: 'column', gap: '8px' }}>
          <label style={{ fontSize: '0.8rem', color: 'var(--text-muted)', fontWeight: 600 }}>Active Task Focus Target:</label>
          <select
            value={selectedTaskId}
            onChange={(e) => setSelectedTaskId(e.target.value)}
            className="input-field"
          >
            <option value="">-- Select a Task to focus on --</option>
            {tasks.filter(t => t.status !== 'done').map(t => (
              <option key={t.id} value={t.id}>{t.title} ({t.priority})</option>
            ))}
          </select>
        </div>

        {/* Web Audio Ambient Soundscapes */}
        <div style={{ width: '100%', display: 'flex', alignItems: 'center', justifyContent: 'space-between', paddingTop: '12px', borderTop: '1px solid var(--border-color)' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <Icon name="Volume" size={16} color="var(--accent-secondary)" />
            <span style={{ fontSize: '0.8rem', fontWeight: 600 }}>Ambient Sound Generator:</span>
          </div>

          <select
            value={ambientSound}
            onChange={handleAmbientChange}
            className="input-field"
            style={{ width: 'auto', padding: '6px 10px', fontSize: '0.8rem' }}
          >
            <option value="none">Off</option>
            <option value="ambient_rain">Soft Rain</option>
            <option value="white_noise">White Noise Focus</option>
            <option value="synth_waves">Deep Space Synth</option>
          </select>
        </div>
      </div>
    </div>
  );
};
