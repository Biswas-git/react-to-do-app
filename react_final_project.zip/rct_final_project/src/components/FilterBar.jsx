export default function FilterBar({
  statusFilter,
  onStatusChange,
  categoryFilter,
  onCategoryChange,
  priorityFilter,
  onPriorityChange,
  categories,
  priorities,
  searchQuery,
  onSearchChange,
  sortBy,
  onSortChange,
  labelFilter,
  onLabelChange,
  allLabels,
}) {
  const statusOptions = [
    { value: 'all', label: 'All' },
    { value: 'active', label: 'Active' },
    { value: 'completed', label: 'Done' },
  ]

  return (
    <div className="filter-bar">
      <div className="filter-row">
        <div className="filter-group" role="group" aria-label="Filter by status">
          {statusOptions.map((option) => (
            <button
              key={option.value}
              className={`filter-btn ${statusFilter === option.value ? 'active' : ''}`}
              onClick={() => onStatusChange(option.value)}
              aria-pressed={statusFilter === option.value}
            >
              {option.label}
            </button>
          ))}
        </div>
        <div className="filter-search">
          <label htmlFor="search-tasks" className="visually-hidden">
            Search tasks
          </label>
          <input
            id="search-tasks"
            type="search"
            className="form-input search-input"
            placeholder="Search tasks..."
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
          />
        </div>
      </div>
      <div className="filter-row">
        <div className="filter-group">
          <label htmlFor="category-filter" className="visually-hidden">
            Filter by category
          </label>
          <select
            id="category-filter"
            className="form-select"
            value={categoryFilter}
            onChange={(e) => onCategoryChange(e.target.value)}
          >
            <option value="all">All Categories</option>
            {categories.map((cat) => (
              <option key={cat} value={cat}>
                {cat}
              </option>
            ))}
          </select>
        </div>
        <div className="filter-group">
          <label htmlFor="priority-filter" className="visually-hidden">
            Filter by priority
          </label>
          <select
            id="priority-filter"
            className="form-select"
            value={priorityFilter}
            onChange={(e) => onPriorityChange(e.target.value)}
          >
            <option value="all">All Priorities</option>
            {priorities.map((p) => (
              <option key={p} value={p}>
                {p}
              </option>
            ))}
          </select>
        </div>
        <div className="filter-group">
          <label htmlFor="label-filter" className="visually-hidden">
            Filter by label
          </label>
          <select
            id="label-filter"
            className="form-select"
            value={labelFilter}
            onChange={(e) => onLabelChange(e.target.value)}
          >
            <option value="all">All Labels</option>
            {allLabels.map((label) => (
              <option key={label} value={label}>
                {label}
              </option>
            ))}
          </select>
        </div>
        <div className="filter-group">
          <label htmlFor="sort-by" className="visually-hidden">
            Sort tasks
          </label>
          <select
            id="sort-by"
            className="form-select"
            value={sortBy}
            onChange={(e) => onSortChange(e.target.value)}
          >
            <option value="newest">Newest First</option>
            <option value="oldest">Oldest First</option>
            <option value="priority">Priority</option>
            <option value="dueDate">Due Date</option>
            <option value="alphabetical">A-Z</option>
          </select>
        </div>
      </div>
    </div>
  )
}
