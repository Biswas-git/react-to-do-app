import React, { useState } from 'react';
import { Icon } from './Icons';

export const GanttView = ({ tasks, onOpenTaskModal }) => {
  const [groupBy, setGroupBy] = useState('category');

  // Timeline date generator (14 days window around today)
  const today = new Date();
  const dateRange = [];
  for (let i = -4; i <= 10; i++) {
    const d = new Date(today);
    d.setDate(d.getDate() + i);
    dateRange.push(d);
  }

  const startDateWindow = dateRange[0];
  const totalDays = dateRange.length;

  const getDayOffset = (dateStr) => {
    if (!dateStr) return 0;
    const d = new Date(dateStr);
    const diffTime = d - startDateWindow;
    const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
    return Math.max(0, Math.min(diffDays, totalDays - 1));
  };

  const categories = ['feature', 'bug', 'design', 'research', 'marketing'];

  return (
    <div style={{ padding: '24px', display: 'flex', flexDirection: 'column', gap: '20px', height: 'calc(100vh - 120px)', overflowY: 'auto' }}>
      {/* Header controls */}
      <div className="glass-panel" style={{ padding: '14px 20px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
          <Icon name="Gantt" size={20} color="var(--accent-primary)" />
          <h2 style={{ fontSize: '1.1rem', fontWeight: 700 }}>Project Schedule & Gantt Timeline</h2>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
          <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)', fontWeight: 600 }}>Group By:</span>
          <select
            value={groupBy}
            onChange={(e) => setGroupBy(e.target.value)}
            className="input-field"
            style={{ width: 'auto', padding: '6px 12px', fontSize: '0.85rem' }}
          >
            <option value="category">Category</option>
            <option value="status">Status</option>
            <option value="priority">Priority</option>
          </select>
        </div>
      </div>

      {/* Main Gantt Grid */}
      <div className="glass-panel" style={{ padding: '20px', overflowX: 'auto', flex: 1 }}>
        <div style={{ minWidth: '900px' }}>
          {/* Calendar Header Row */}
          <div style={{ display: 'grid', gridTemplateColumns: '220px repeat(15, 1fr)', borderBottom: '1px solid var(--border-color)', paddingBottom: '12px' }}>
            <div style={{ fontSize: '0.8rem', fontWeight: 700, color: 'var(--text-secondary)' }}>
              Task Name / Group
            </div>
            {dateRange.map((d, i) => {
              const isToday = d.toDateString() === today.toDateString();
              return (
                <div key={i} style={{ textAlign: 'center', fontSize: '0.725rem', fontWeight: 700, color: isToday ? 'var(--accent-primary)' : 'var(--text-muted)' }}>
                  <div>{d.toLocaleDateString('en-US', { weekday: 'short' })}</div>
                  <div style={{ fontSize: '0.85rem', color: isToday ? 'var(--accent-primary)' : 'var(--text-primary)' }}>{d.getDate()}</div>
                </div>
              );
            })}
          </div>

          {/* Gantt Rows Grouped */}
          {tasks.length === 0 ? (
            <div style={{ textAlign: 'center', padding: '40px', color: 'var(--text-muted)' }}>
              No tasks scheduled for timeline view.
            </div>
          ) : (
            tasks.map(task => {
              const startOffset = getDayOffset(task.startDate || task.createdAt);
              const endOffset = getDayOffset(task.dueDate || task.startDate || task.createdAt);
              const spanDays = Math.max(1, endOffset - startOffset + 1);

              const leftPct = (startOffset / totalDays) * 100;
              const widthPct = (spanDays / totalDays) * 100;

              const completedSubtasks = task.subtasks ? task.subtasks.filter(s => s.completed).length : 0;
              const totalSubtasks = task.subtasks ? task.subtasks.length : 0;
              const progressPct = totalSubtasks > 0 ? (completedSubtasks / totalSubtasks) * 100 : (task.status === 'done' ? 100 : 0);

              return (
                <div
                  key={task.id}
                  onClick={() => onOpenTaskModal(task)}
                  style={{
                    display: 'grid',
                    gridTemplateColumns: '220px 1fr',
                    alignItems: 'center',
                    padding: '12px 0',
                    borderBottom: '1px solid rgba(255, 255, 255, 0.04)',
                    cursor: 'pointer'
                  }}
                >
                  {/* Task Metadata Column */}
                  <div style={{ paddingRight: '12px' }}>
                    <div style={{ fontSize: '0.85rem', fontWeight: 600, color: 'var(--text-primary)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                      {task.title}
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '6px', marginTop: '2px' }}>
                      <span className={`badge badge-${task.priority}`} style={{ fontSize: '0.65rem' }}>
                        {task.priority}
                      </span>
                      <span style={{ fontSize: '0.7rem', color: 'var(--text-muted)' }}>
                        {task.category}
                      </span>
                    </div>
                  </div>

                  {/* Gantt Timeline Track */}
                  <div style={{ position: 'relative', height: '32px', background: 'rgba(255, 255, 255, 0.02)', borderRadius: '6px' }}>
                    {/* Task Schedule Bar */}
                    <div style={{
                      position: 'absolute',
                      left: `${leftPct}%`,
                      width: `${widthPct}%`,
                      top: '4px',
                      height: '24px',
                      borderRadius: '6px',
                      background: 'linear-gradient(90deg, var(--accent-primary), var(--accent-purple))',
                      boxShadow: '0 2px 8px var(--accent-glow)',
                      display: 'flex',
                      alignItems: 'center',
                      padding: '0 10px',
                      color: '#fff',
                      fontSize: '0.75rem',
                      fontWeight: 600,
                      overflow: 'hidden',
                      whiteSpace: 'nowrap'
                    }}>
                      {/* Progress Overlay */}
                      <div style={{
                        position: 'absolute',
                        left: 0,
                        top: 0,
                        bottom: 0,
                        width: `${progressPct}%`,
                        background: 'rgba(255, 255, 255, 0.25)'
                      }} />
                      <span style={{ position: 'relative', zIndex: 1 }}>{task.title}</span>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};
