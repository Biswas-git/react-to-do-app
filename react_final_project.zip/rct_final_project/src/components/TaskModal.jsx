import React, { useState, useEffect } from 'react';
import { Icon } from './Icons';
import { aiAssistant } from '../utils/aiSimulator';
import { soundFx } from '../utils/audio';

export const TaskModal = ({ task, isNew, onClose, onSave, onDelete }) => {
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    status: 'todo',
    priority: 'medium',
    category: 'feature',
    startDate: '',
    dueDate: '',
    estimatedHours: 4,
    loggedHours: 0,
    tags: [],
    subtasks: [],
    dependencies: [],
    matrixQuadrant: 'schedule',
    canvasPosition: { x: 150, y: 150 }
  });

  const [tagInput, setTagInput] = useState('');
  const [subtaskInput, setSubtaskInput] = useState('');

  useEffect(() => {
    if (task) {
      setFormData({
        ...task,
        subtasks: task.subtasks || [],
        tags: task.tags || [],
        dependencies: task.dependencies || []
      });
    }
  }, [task]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleAddTag = () => {
    if (tagInput.trim() && !formData.tags.includes(tagInput.trim())) {
      setFormData(prev => ({ ...prev, tags: [...prev.tags, tagInput.trim()] }));
      setTagInput('');
    }
  };

  const handleRemoveTag = (tag) => {
    setFormData(prev => ({ ...prev, tags: prev.tags.filter(t => t !== tag) }));
  };

  const handleAddSubtask = () => {
    if (subtaskInput.trim()) {
      const newSub = { id: `st-${Date.now()}`, title: subtaskInput.trim(), completed: false };
      setFormData(prev => ({ ...prev, subtasks: [...prev.subtasks, newSub] }));
      setSubtaskInput('');
    }
  };

  const handleToggleSubtask = (stId) => {
    setFormData(prev => {
      const updated = prev.subtasks.map(s => s.id === stId ? { ...s, completed: !s.completed } : s);
      const allDone = updated.length > 0 && updated.every(s => s.completed);
      if (allDone) soundFx.playSuccess();
      return {
        ...prev,
        subtasks: updated,
        status: allDone ? 'done' : prev.status
      };
    });
  };

  const handleRemoveSubtask = (stId) => {
    setFormData(prev => ({ ...prev, subtasks: prev.subtasks.filter(s => s.id !== stId) }));
  };

  const handleAiBreakdown = () => {
    if (!formData.title.trim()) {
      alert("Please enter a Task Title first so AI can generate subtasks!");
      return;
    }
    const generated = aiAssistant.generateSubtasks(formData.title, formData.category);
    const predicted = aiAssistant.predictMeta(formData.title);

    soundFx.playSuccess();
    setFormData(prev => ({
      ...prev,
      subtasks: [...prev.subtasks, ...generated],
      priority: prev.priority || predicted.priority,
      category: prev.category || predicted.category,
      matrixQuadrant: prev.matrixQuadrant || predicted.matrixQuadrant
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.title.trim()) return;
    onSave(formData);
    soundFx.playClick();
  };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content" onClick={(e) => e.stopPropagation()}>
        {/* Header */}
        <div style={{ padding: '20px', borderBottom: '1px solid var(--border-color)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <h2 style={{ fontSize: '1.2rem', fontWeight: 800 }}>
            {isNew ? '✨ Create New Task' : 'Edit Task Specifications'}
          </h2>
          <button onClick={onClose} className="btn btn-outline btn-icon">
            <Icon name="Close" size={16} />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} style={{ padding: '20px', display: 'flex', flexDirection: 'column', gap: '16px' }}>
          {/* Title */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <label style={{ fontSize: '0.8rem', color: 'var(--text-muted)', fontWeight: 700 }}>Task Title *</label>
              <button
                type="button"
                onClick={handleAiBreakdown}
                className="btn btn-sm"
                style={{ background: 'rgba(139, 92, 246, 0.15)', color: '#c084fc', border: '1px solid rgba(139, 92, 246, 0.4)' }}
              >
                <Icon name="Sparkles" size={14} color="#c084fc" />
                <span>AI Auto Subtasks</span>
              </button>
            </div>
            <input
              type="text"
              name="title"
              placeholder="e.g. Implement OAuth2 Refresh Tokens"
              value={formData.title}
              onChange={handleChange}
              className="input-field"
              required
            />
          </div>

          {/* Description */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
            <label style={{ fontSize: '0.8rem', color: 'var(--text-muted)', fontWeight: 700 }}>Description / Notes</label>
            <textarea
              name="description"
              placeholder="Add task context, architecture requirements, or acceptance criteria..."
              value={formData.description}
              onChange={handleChange}
              className="input-field"
            />
          </div>

          {/* Metadata Row 1 */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '12px' }}>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
              <label style={{ fontSize: '0.8rem', color: 'var(--text-muted)', fontWeight: 700 }}>Status</label>
              <select name="status" value={formData.status} onChange={handleChange} className="input-field">
                <option value="backlog">Backlog</option>
                <option value="todo">To Do</option>
                <option value="in_progress">In Progress</option>
                <option value="review">In Review</option>
                <option value="done">Completed</option>
              </select>
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
              <label style={{ fontSize: '0.8rem', color: 'var(--text-muted)', fontWeight: 700 }}>Priority</label>
              <select name="priority" value={formData.priority} onChange={handleChange} className="input-field">
                <option value="low">Low</option>
                <option value="medium">Medium</option>
                <option value="high">High</option>
                <option value="critical">Critical</option>
              </select>
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
              <label style={{ fontSize: '0.8rem', color: 'var(--text-muted)', fontWeight: 700 }}>Category</label>
              <select name="category" value={formData.category} onChange={handleChange} className="input-field">
                <option value="feature">Feature</option>
                <option value="bug">Bug Fix</option>
                <option value="design">Design</option>
                <option value="research">Research</option>
                <option value="marketing">Marketing</option>
              </select>
            </div>
          </div>

          {/* Metadata Row 2 */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr 1fr', gap: '12px' }}>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
              <label style={{ fontSize: '0.8rem', color: 'var(--text-muted)', fontWeight: 700 }}>Start Date</label>
              <input type="date" name="startDate" value={formData.startDate} onChange={handleChange} className="input-field" />
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
              <label style={{ fontSize: '0.8rem', color: 'var(--text-muted)', fontWeight: 700 }}>Due Date</label>
              <input type="date" name="dueDate" value={formData.dueDate} onChange={handleChange} className="input-field" />
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
              <label style={{ fontSize: '0.8rem', color: 'var(--text-muted)', fontWeight: 700 }}>Est. Hours</label>
              <input type="number" name="estimatedHours" value={formData.estimatedHours} onChange={handleChange} className="input-field" min="1" />
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
              <label style={{ fontSize: '0.8rem', color: 'var(--text-muted)', fontWeight: 700 }}>Logged Hours</label>
              <input type="number" name="loggedHours" value={formData.loggedHours} onChange={handleChange} className="input-field" min="0" />
            </div>
          </div>

          {/* Subtasks Section */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', marginTop: '6px' }}>
            <label style={{ fontSize: '0.8rem', color: 'var(--text-muted)', fontWeight: 700 }}>
              Subtasks Checklist ({formData.subtasks.filter(s => s.completed).length}/{formData.subtasks.length})
            </label>

            <div style={{ display: 'flex', gap: '8px' }}>
              <input
                type="text"
                placeholder="Add subtask..."
                value={subtaskInput}
                onChange={(e) => setSubtaskInput(e.target.value)}
                onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); handleAddSubtask(); } }}
                className="input-field"
              />
              <button type="button" onClick={handleAddSubtask} className="btn btn-secondary btn-sm">
                Add
              </button>
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '6px', maxHeight: '150px', overflowY: 'auto' }}>
              {formData.subtasks.map(st => (
                <div key={st.id} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', background: 'var(--bg-tertiary)', padding: '6px 10px', borderRadius: '6px' }}>
                  <label style={{ display: 'flex', alignItems: 'center', gap: '8px', cursor: 'pointer', fontSize: '0.85rem' }}>
                    <input type="checkbox" checked={st.completed} onChange={() => handleToggleSubtask(st.id)} />
                    <span style={{ textDecoration: st.completed ? 'line-through' : 'none', color: st.completed ? 'var(--text-muted)' : 'var(--text-primary)' }}>
                      {st.title}
                    </span>
                  </label>
                  <button type="button" onClick={() => handleRemoveSubtask(st.id)} style={{ background: 'none', border: 'none', color: '#ef4444', cursor: 'pointer' }}>
                    &times;
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* Footer Actions */}
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginTop: '14px', paddingTop: '14px', borderTop: '1px solid var(--border-color)' }}>
            {!isNew ? (
              <button type="button" onClick={() => onDelete(task.id)} className="btn btn-danger btn-sm">
                <Icon name="Trash" size={14} />
                <span>Delete Task</span>
              </button>
            ) : <div />}

            <div style={{ display: 'flex', gap: '10px' }}>
              <button type="button" onClick={onClose} className="btn btn-secondary btn-sm">
                Cancel
              </button>
              <button type="submit" className="btn btn-primary btn-sm">
                {isNew ? 'Create Task' : 'Save Changes'}
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
