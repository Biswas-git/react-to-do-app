import React, { useState, useRef } from 'react';
import { Icon } from './Icons';

export const CanvasView = ({ tasks, onUpdateTaskCanvasPosition, onAddDependency, onOpenTaskModal, onQuickAddTaskAtPosition }) => {
  const [zoom, setZoom] = useState(1);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const [isPanning, setIsPanning] = useState(false);
  const [startPan, setStartPan] = useState({ x: 0, y: 0 });
  const [connectMode, setConnectMode] = useState(false);
  const [selectedParentId, setSelectedParentId] = useState(null);

  const [draggingTaskId, setDraggingTaskId] = useState(null);
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });

  const canvasRef = useRef(null);

  const handleMouseDownCanvas = (e) => {
    // If clicking on canvas background, handle panning
    if (e.target === canvasRef.current || e.target.tagName === 'svg' || e.target.classList.contains('canvas-grid')) {
      setIsPanning(true);
      setStartPan({ x: e.clientX - pan.x, y: e.clientY - pan.y });
    }
  };

  const handleMouseMoveCanvas = (e) => {
    if (isPanning) {
      setPan({ x: e.clientX - startPan.x, y: e.clientY - startPan.y });
    } else if (draggingTaskId) {
      const newX = Math.round((e.clientX - pan.x - dragOffset.x) / zoom);
      const newY = Math.round((e.clientY - pan.y - dragOffset.y) / zoom);
      onUpdateTaskCanvasPosition(draggingTaskId, { x: newX, y: newY });
    }
  };

  const handleMouseUpCanvas = () => {
    setIsPanning(false);
    setDraggingTaskId(null);
  };

  const handleDoubleClickCanvas = (e) => {
    if (canvasRef.current && e.target === canvasRef.current) {
      const rect = canvasRef.current.getBoundingClientRect();
      const clickX = Math.round((e.clientX - rect.left - pan.x) / zoom);
      const clickY = Math.round((e.clientY - rect.top - pan.y) / zoom);
      const title = prompt("Enter new Spatial Node title:");
      if (title && title.trim()) {
        onQuickAddTaskAtPosition(title.trim(), { x: clickX, y: clickY });
      }
    }
  };

  const handleNodeMouseDown = (e, task) => {
    e.stopPropagation();
    if (connectMode) {
      if (!selectedParentId) {
        setSelectedParentId(task.id);
      } else if (selectedParentId !== task.id) {
        onAddDependency(task.id, selectedParentId);
        setSelectedParentId(null);
        setConnectMode(false);
      }
    } else {
      setDraggingTaskId(task.id);
      const cardRect = e.currentTarget.getBoundingClientRect();
      setDragOffset({
        x: e.clientX - cardRect.left,
        y: e.clientY - cardRect.top
      });
    }
  };

  // Find line connections between tasks and dependencies
  const connections = [];
  tasks.forEach(task => {
    if (task.dependencies && task.dependencies.length > 0) {
      task.dependencies.forEach(depId => {
        const parentTask = tasks.find(t => t.id === depId);
        if (parentTask) {
          const fromPos = parentTask.canvasPosition || { x: 100, y: 100 };
          const toPos = task.canvasPosition || { x: 300, y: 100 };
          connections.push({
            id: `${parentTask.id}-${task.id}`,
            fromX: fromPos.x + 120,
            fromY: fromPos.y + 50,
            toX: toPos.x + 120,
            toY: toPos.y + 50,
            fromTitle: parentTask.title,
            toTitle: task.title
          });
        }
      });
    }
  });

  return (
    <div style={{ position: 'relative', width: '100%', height: 'calc(100vh - 120px)', overflow: 'hidden', background: '#070a13' }}>
      {/* Control Overlay Bar */}
      <div className="glass-panel" style={{
        position: 'absolute',
        top: '20px',
        left: '20px',
        zIndex: 10,
        display: 'flex',
        alignItems: 'center',
        gap: '10px',
        padding: '10px 16px',
        borderRadius: '12px'
      }}>
        <button
          onClick={() => setZoom(z => Math.min(z + 0.1, 2))}
          className="btn btn-secondary btn-sm"
          title="Zoom In"
        >
          +
        </button>
        <span style={{ fontSize: '0.8rem', fontWeight: 700, color: 'var(--text-secondary)', minWidth: '45px', textAlign: 'center' }}>
          {Math.round(zoom * 100)}%
        </span>
        <button
          onClick={() => setZoom(z => Math.max(z - 0.1, 0.4))}
          className="btn btn-secondary btn-sm"
          title="Zoom Out"
        >
          -
        </button>
        <button
          onClick={() => { setZoom(1); setPan({ x: 0, y: 0 }); }}
          className="btn btn-outline btn-sm"
        >
          Reset View
        </button>

        <div style={{ width: '1px', height: '20px', background: 'var(--border-color)' }} />

        <button
          onClick={() => {
            setConnectMode(!connectMode);
            setSelectedParentId(null);
          }}
          className={`btn btn-sm ${connectMode ? 'btn-primary' : 'btn-secondary'}`}
        >
          <Icon name="Canvas" size={14} />
          <span>{connectMode ? (selectedParentId ? 'Click target node to connect' : 'Click parent node') : 'Connect Dependency'}</span>
        </button>

        <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginLeft: '10px' }}>
          💡 Double-click canvas to create a node. Drag cards to organize spatially.
        </span>
      </div>

      {/* Main Interactive Canvas Area */}
      <div
        ref={canvasRef}
        onMouseDown={handleMouseDownCanvas}
        onMouseMove={handleMouseMoveCanvas}
        onMouseUp={handleMouseUpCanvas}
        onDoubleClick={handleDoubleClickCanvas}
        className="canvas-grid"
        style={{
          width: '100%',
          height: '100%',
          cursor: isPanning ? 'grabbing' : 'grab',
          backgroundImage: 'radial-gradient(rgba(255, 255, 255, 0.08) 1px, transparent 1px)',
          backgroundSize: `${30 * zoom}px ${30 * zoom}px`,
          backgroundPosition: `${pan.x}px ${pan.y}px`,
          position: 'relative'
        }}
      >
        <div style={{
          transform: `translate(${pan.x}px, ${pan.y}px) scale(${zoom})`,
          transformOrigin: '0 0',
          width: '100%',
          height: '100%',
          position: 'absolute',
          top: 0,
          left: 0
        }}>
          {/* SVG Dependency Connecting Paths */}
          <svg style={{ position: 'absolute', top: 0, left: 0, width: '4000px', height: '4000px', pointerEvents: 'none' }}>
            <defs>
              <marker id="arrow" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
                <path d="M 0 0 L 10 5 L 0 10 z" fill="var(--accent-primary)" />
              </marker>
            </defs>
            {connections.map(conn => {
              const dx = conn.toX - conn.fromX;
              const dy = conn.toY - conn.fromY;
              const cx1 = conn.fromX + dx / 2;
              const cy1 = conn.fromY;
              const cx2 = conn.fromX + dx / 2;
              const cy2 = conn.toY;
              const pathString = `M ${conn.fromX} ${conn.fromY} C ${cx1} ${cy1}, ${cx2} ${cy2}, ${conn.toX} ${conn.toY}`;

              return (
                <g key={conn.id}>
                  <path
                    d={pathString}
                    stroke="var(--accent-primary)"
                    strokeWidth="2.5"
                    fill="none"
                    strokeDasharray="6 3"
                    markerEnd="url(#arrow)"
                    opacity="0.85"
                  />
                </g>
              );
            })}
          </svg>

          {/* Spatial Task Node Cards */}
          {tasks.map(task => {
            const pos = task.canvasPosition || { x: 100, y: 100 };
            const isSelectedForConnect = selectedParentId === task.id;

            return (
              <div
                key={task.id}
                onMouseDown={(e) => handleNodeMouseDown(e, task)}
                onDoubleClick={(e) => { e.stopPropagation(); onOpenTaskModal(task); }}
                className="glass-panel"
                style={{
                  position: 'absolute',
                  left: `${pos.x}px`,
                  top: `${pos.y}px`,
                  width: '240px',
                  padding: '14px',
                  cursor: draggingTaskId === task.id ? 'grabbing' : 'pointer',
                  border: isSelectedForConnect ? '2px solid var(--accent-pink)' : '1px solid var(--border-color)',
                  boxShadow: isSelectedForConnect ? '0 0 20px rgba(236, 72, 153, 0.4)' : 'var(--shadow-md)',
                  background: 'var(--bg-card)',
                  userSelect: 'none',
                  borderRadius: 'var(--radius-lg)'
                }}
              >
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '6px' }}>
                  <span className={`badge badge-${task.priority}`}>{task.priority}</span>
                  <span style={{ fontSize: '0.7rem', color: 'var(--text-muted)', fontWeight: 600 }}>{task.category}</span>
                </div>

                <h4 style={{ fontSize: '0.9rem', fontWeight: 700, color: 'var(--text-primary)', marginBottom: '4px' }}>
                  {task.title}
                </h4>

                {task.description && (
                  <p style={{ fontSize: '0.75rem', color: 'var(--text-muted)', display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', overflow: 'hidden' }}>
                    {task.description}
                  </p>
                )}

                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginTop: '10px', fontSize: '0.7rem' }}>
                  <span style={{ color: task.status === 'done' ? '#10b981' : 'var(--accent-primary)', fontWeight: 700, textTransform: 'uppercase' }}>
                    {task.status.replace('_', ' ')}
                  </span>
                  <span style={{ color: 'var(--text-muted)' }}>
                    {task.subtasks ? `${task.subtasks.filter(s => s.completed).length}/${task.subtasks.length} subtasks` : ''}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
