import React from 'react';

export const Icon = ({ name, size = 18, color = 'currentColor', className = '', ...props }) => {
  const iconProps = {
    width: size,
    height: size,
    stroke: color,
    strokeWidth: 2,
    strokeLinecap: 'round',
    strokeLinejoin: 'round',
    fill: 'none',
    className,
    ...props
  };

  switch (name) {
    case 'Kanban':
      return (
        <svg viewBox="0 0 24 24" {...iconProps}>
          <rect x="3" y="3" width="5" height="18" rx="1" />
          <rect x="11" y="3" width="5" height="12" rx="1" />
          <rect x="19" y="3" width="5" height="15" rx="1" />
        </svg>
      );
    case 'Canvas':
      return (
        <svg viewBox="0 0 24 24" {...iconProps}>
          <circle cx="6" cy="6" r="3" />
          <circle cx="18" cy="6" r="3" />
          <circle cx="12" cy="18" r="3" />
          <line x1="8.5" y1="7.5" x2="15.5" y2="7.5" />
          <line x1="7.5" y1="8.5" x2="10.5" y2="15.5" />
          <line x1="16.5" y1="8.5" x2="13.5" y2="15.5" />
        </svg>
      );
    case 'Gantt':
      return (
        <svg viewBox="0 0 24 24" {...iconProps}>
          <path d="M3 3v18h18" />
          <rect x="7" y="6" width="9" height="3" rx="1" />
          <rect x="11" y="11" width="8" height="3" rx="1" />
          <rect x="5" y="16" width="10" height="3" rx="1" />
        </svg>
      );
    case 'Matrix':
      return (
        <svg viewBox="0 0 24 24" {...iconProps}>
          <rect x="3" y="3" width="8" height="8" rx="1" />
          <rect x="13" y="3" width="8" height="8" rx="1" />
          <rect x="3" y="13" width="8" height="8" rx="1" />
          <rect x="13" y="13" width="8" height="8" rx="1" />
        </svg>
      );
    case 'Calendar':
      return (
        <svg viewBox="0 0 24 24" {...iconProps}>
          <rect x="3" y="4" width="18" height="18" rx="2" ry="2" />
          <line x1="16" y1="2" x2="16" y2="6" />
          <line x1="8" y1="2" x2="8" y2="6" />
          <line x1="3" y1="10" x2="21" y2="10" />
        </svg>
      );
    case 'Analytics':
      return (
        <svg viewBox="0 0 24 24" {...iconProps}>
          <line x1="18" y1="20" x2="18" y2="10" />
          <line x1="12" y1="20" x2="12" y2="4" />
          <line x1="6" y1="20" x2="6" y2="14" />
        </svg>
      );
    case 'Focus':
      return (
        <svg viewBox="0 0 24 24" {...iconProps}>
          <circle cx="12" cy="12" r="10" />
          <polyline points="12 6 12 12 16 14" />
        </svg>
      );
    case 'Automation':
      return (
        <svg viewBox="0 0 24 24" {...iconProps}>
          <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2" />
        </svg>
      );
    case 'Sparkles':
      return (
        <svg viewBox="0 0 24 24" {...iconProps}>
          <path d="M12 2l2.4 5.6L20 10l-5.6 2.4L12 18l-2.4-5.6L4 10l5.6-2.4L12 2z" />
          <path d="M19 16l1.2 2.8L23 20l-2.8 1.2L19 24l-1.2-2.8L15 20l2.8-1.2L19 16z" />
        </svg>
      );
    case 'Plus':
      return (
        <svg viewBox="0 0 24 24" {...iconProps}>
          <line x1="12" y1="5" x2="12" y2="19" />
          <line x1="5" y1="12" x2="19" y2="12" />
        </svg>
      );
    case 'Trash':
      return (
        <svg viewBox="0 0 24 24" {...iconProps}>
          <polyline points="3 6 5 6 21 6" />
          <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" />
        </svg>
      );
    case 'Edit':
      return (
        <svg viewBox="0 0 24 24" {...iconProps}>
          <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" />
          <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" />
        </svg>
      );
    case 'Search':
      return (
        <svg viewBox="0 0 24 24" {...iconProps}>
          <circle cx="11" cy="11" r="8" />
          <line x1="21" y1="21" x2="16.65" y2="16.65" />
        </svg>
      );
    case 'Moon':
      return (
        <svg viewBox="0 0 24 24" {...iconProps}>
          <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z" />
        </svg>
      );
    case 'Sun':
      return (
        <svg viewBox="0 0 24 24" {...iconProps}>
          <circle cx="12" cy="12" r="5" />
          <line x1="12" y1="1" x2="12" y2="3" />
          <line x1="12" y1="21" x2="12" y2="23" />
          <line x1="4.22" y1="4.22" x2="5.64" y2="5.64" />
          <line x1="18.36" y1="18.36" x2="19.78" y2="19.78" />
          <line x1="1" y1="12" x2="3" y2="12" />
          <line x1="21" y1="12" x2="23" y2="12" />
          <line x1="4.22" y1="19.78" x2="5.64" y2="18.36" />
          <line x1="18.36" y1="5.64" x2="19.78" y2="4.22" />
        </svg>
      );
    case 'Check':
      return (
        <svg viewBox="0 0 24 24" {...iconProps}>
          <polyline points="20 6 9 17 4 12" />
        </svg>
      );
    case 'Play':
      return (
        <svg viewBox="0 0 24 24" {...iconProps}>
          <polygon points="5 3 19 12 5 21 5 3" />
        </svg>
      );
    case 'Pause':
      return (
        <svg viewBox="0 0 24 24" {...iconProps}>
          <rect x="6" y="4" width="4" height="16" />
          <rect x="14" y="4" width="4" height="16" />
        </svg>
      );
    case 'Refresh':
      return (
        <svg viewBox="0 0 24 24" {...iconProps}>
          <polyline points="23 4 23 10 17 10" />
          <path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10" />
        </svg>
      );
    case 'Code':
      return (
        <svg viewBox="0 0 24 24" {...iconProps}>
          <polyline points="16 18 22 12 16 6" />
          <polyline points="8 6 2 12 8 18" />
        </svg>
      );
    case 'Palette':
      return (
        <svg viewBox="0 0 24 24" {...iconProps}>
          <circle cx="13.5" cy="6.5" r=".5" fill="currentColor" />
          <circle cx="17.5" cy="10.5" r=".5" fill="currentColor" />
          <circle cx="8.5" cy="7.5" r=".5" fill="currentColor" />
          <path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.92 0 1.67-.75 1.67-1.67 0-.43-.17-.83-.44-1.14-.26-.3-.43-.7-.43-1.15 0-.92.75-1.67 1.67-1.67H16c3.31 0 6-2.69 6-6 0-4.96-4.49-9-10-9z" />
        </svg>
      );
    case 'Rocket':
      return (
        <svg viewBox="0 0 24 24" {...iconProps}>
          <path d="M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.71.79-1.81.2-2.71l-2.48-2.48c-.9-.59-2-.51-2.72.19z" />
          <path d="M15 9l-6 6" />
          <path d="M9 15l-3-3" />
          <path d="M12 18l3 3" />
          <path d="M10 6l6 6" />
          <path d="M15 3a9 9 0 0 1 6 6c0 3-3 6-6 6l-6-6c0-3 3-6 6-6z" />
        </svg>
      );
    case 'User':
      return (
        <svg viewBox="0 0 24 24" {...iconProps}>
          <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" />
          <circle cx="12" cy="7" r="4" />
        </svg>
      );
    case 'Download':
      return (
        <svg viewBox="0 0 24 24" {...iconProps}>
          <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
          <polyline points="7 10 12 15 17 10" />
          <line x1="12" y1="15" x2="12" y2="3" />
        </svg>
      );
    case 'Upload':
      return (
        <svg viewBox="0 0 24 24" {...iconProps}>
          <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
          <polyline points="17 8 12 3 7 8" />
          <line x1="12" y1="3" x2="12" y2="15" />
        </svg>
      );
    case 'Volume':
      return (
        <svg viewBox="0 0 24 24" {...iconProps}>
          <polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5" />
          <path d="M19.07 4.93a10 10 0 0 1 0 14.14M15.54 8.46a5 5 0 0 1 0 7.07" />
        </svg>
      );
    case 'VolumeX':
      return (
        <svg viewBox="0 0 24 24" {...iconProps}>
          <polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5" />
          <line x1="23" y1="9" x2="17" y2="15" />
          <line x1="17" y1="9" x2="23" y2="15" />
        </svg>
      );
    case 'Close':
      return (
        <svg viewBox="0 0 24 24" {...iconProps}>
          <line x1="18" y1="6" x2="6" y2="18" />
          <line x1="6" y1="6" x2="18" y2="18" />
        </svg>
      );
    case 'Zap':
      return (
        <svg viewBox="0 0 24 24" {...iconProps}>
          <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2" />
        </svg>
      );
    case 'ShieldCheck':
      return (
        <svg viewBox="0 0 24 24" {...iconProps}>
          <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" fill="rgba(99, 102, 241, 0.2)" />
          <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
          <polyline points="9 12 11 14 15 10" />
        </svg>
      );
    case 'ChevronUp':
      return (
        <svg viewBox="0 0 24 24" {...iconProps}>
          <polyline points="18 15 12 9 6 15" />
        </svg>
      );
    case 'ChevronDown':
      return (
        <svg viewBox="0 0 24 24" {...iconProps}>
          <polyline points="6 9 12 15 18 9" />
        </svg>
      );
    case 'CheckCircle2':
      return (
        <svg viewBox="0 0 24 24" {...iconProps}>
          <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" />
          <polyline points="22 4 12 14.01 9 11.01" />
        </svg>
      );
    case 'ListTodo':
      return (
        <svg viewBox="0 0 24 24" {...iconProps}>
          <rect x="3" y="5" width="6" height="6" rx="1" />
          <path d="m3 17 2 2 4-4" />
          <path d="M13 6h8" />
          <path d="M13 12h8" />
          <path d="M13 18h8" />
        </svg>
      );
    default:
      return (
        <svg viewBox="0 0 24 24" {...iconProps}>
          <circle cx="12" cy="12" r="10" />
        </svg>
      );
  }
};
