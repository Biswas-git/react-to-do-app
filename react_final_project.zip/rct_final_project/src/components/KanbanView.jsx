import React, { useState } from 'react';
import { Icon } from './Icons';

export const KanbanView = ({ tasks, onUpdateTaskStatus, onDeleteTask, onOpenTaskModal, onQuickAddTask }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [priorityFilter, setPriorityFilter] = useState('all');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [inlineInput, setInlineInput] = useState({});

  const columns = [
    { id: 'backlog', label: 'Backlog', color: '#8b5cf6' },
    { id: 'todo', label: 'To Do', color: '#64748b' },
    { id: 'in_progress', label: 'In Progress', color: '#3b82f6' },
    { id: 'review', label: 'In Review', color: '#f59e0b' },
    { id: 'done', label: 'Completed', color: '#10b981' }
  ];

  // Filtering
  const filteredTasks = tasks.filter(task => {
    const matchesSearch = task.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (task.description && task.description.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (task.tags && task.tags.some(t => t.toLowerCase().includes(searchTerm.toLowerCase())));

    const matchesPriority = priorityFilter === 'all' || task.priority === priorityFilter;
    const matchesCategory = categoryFilter === 'all' || task.category === categoryFilter;

    return matchesSearch && matchesPriority && matchesCategory;
  });

  const handleDragStart = (e, taskId) => {
    e.dataTransfer.setData('text/plain', taskId);
  };

  const handleDragOver = (e) => {
    e.preventDefault();
  };

  const handleDrop = (e, targetStatus) => {
    e.preventDefault();
    const taskId = e.dataTransfer.getData('text/plain');
    if (taskId) {
      onUpdateTaskStatus(taskId, targetStatus);
    }
  };

  const handleInlineSubmit = (status) => {
    const title = inlineInput[status];
    if (title && title.trim()) {
      onQuickAddTask(title.trim(), status);
      setInlineInput(prev => ({ ...prev, [status]: '' }));
    }
  };

  return (
    <div style={{ padding: '24px', display: 'flex', flexDirection: 'column', gap: '20px', height: 'calc(100vh - 120px)' }}>
      {/* Filter & Search Bar */}
      <div className="glass-panel" style={{ padding: '14px 20px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '12px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px', flex: 1, minWidth: '260px' }}>
          <div style={{ position: 'relative', width: '100%', maxWidth: '320px' }}>
            <input
              type="text"
              placeholder="Filter tasks by title, tag, description..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="input-field"
              style={{ paddingLeft: '36px' }}
            />
            <div style={{ position: 'absolute', left: '12px', top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)' }}>
              <Icon name="Search" size={16} />
            </div>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)', fontWeight: 600 }}>Priority:</span>
            <select
              value={priorityFilter}
              onChange={(e) => setPriorityFilter(e.target.value)}
              className="input-field"
              style={{ width: 'auto', padding: '6px 10px', fontSize: '0.8rem' }}
            >
              <option value="all">All Priorities</option>
              <option value="low">Low</option>
              <option value="medium">Medium</option>
              <option value="high">High</option>
              <option value="critical">Critical</option>
            </select>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)', fontWeight: 600 }}>Category:</span>
            <select
              value={categoryFilter}
              onChange={(e) => setCategoryFilter(e.target.value)}
              className="input-field"
              style={{ width: 'auto', padding: '6px 10px', fontSize: '0.8rem' }}
            >
              <option value="all">All Categories</option>
              <option value="feature">Feature</option>
              <option value="bug">Bug Fix</option>
              <option value="design">Design</option>
              <option value="research">Research</option>
              <option value="marketing">Marketing</option>
            </select>
          </div>
        </div>

        <div style={{ fontSize: '0.8rem', color: 'var(--text-secondary)', fontWeight: 600 }}>
          Showing {filteredTasks.length} of {tasks.length} tasks
        </div>
      </div>

      {/* Kanban Board Columns */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '16px', flex: 1, overflowY: 'auto' }}>
        {columns.map(col => {
          const colTasks = filteredTasks.filter(t => t.status === col.id);
          return (
            <div
              key={col.id}
              onDragOver={handleDragOver}
              onDrop={(e) => handleDrop(e, col.id)}
              className="glass-panel"
              style={{
                display: 'flex',
                flexDirection: 'column',
                padding: '16px',
                background: 'var(--bg-glass)',
                height: '100%',
                maxHeight: '100%'
              }}
            >
              {/* Column Header */}
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '14px' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                  <div style={{ width: '10px', height: '10px', borderRadius: '50%', background: col.color }} />
                  <h3 style={{ fontSize: '0.95rem', fontWeight: 700 }}>{col.label}</h3>
                  <span style={{
                    background: 'var(--bg-tertiary)',
                    padding: '2px 8px',
                    borderRadius: '12px',
                    fontSize: '0.75rem',
                    fontWeight: 700,
                    color: 'var(--text-secondary)'
                  }}>
                    {colTasks.length}
                  </span>
                </div>
              </div>

              {/* Quick Task Add Input */}
              <div style={{ marginBottom: '12px', display: 'flex', gap: '6px' }}>
                <input
                  type="text"
                  placeholder={`+ Add task to ${col.label}...`}
                  value={inlineInput[col.id] || ''}
                  onChange={(e) => setInlineInput({ ...inlineInput, [col.id]: e.target.value })}
                  onKeyDown={(e) => e.key === 'Enter' && handleInlineSubmit(col.id)}
                  className="input-field"
                  style={{ fontSize: '0.8rem', padding: '6px 10px' }}
                />
              </div>

              {/* Task Cards List */}
              <div style={{ display: 'flex', flexDirection: 'column', gap: '10px', overflowY: 'auto', flex: 1, paddingRight: '4px' }}>
                {colTasks.map(task => {
                  const completedSubtasks = task.subtasks ? task.subtasks.filter(s => s.completed).length : 0;
                  const totalSubtasks = task.subtasks ? task.subtasks.length : 0;
                  const subtaskPct = totalSubtasks > 0 ? Math.round((completedSubtasks / totalSubtasks) * 100) : 0;

                  return (
                    <div
                      key={task.id}
                      draggable
                      onDragStart={(e) => handleDragStart(e, task.id)}
                      onClick={() => onOpenTaskModal(task)}
                      className="glass-panel"
                      style={{
                        padding: '14px',
                        cursor: 'grab',
                        background: 'var(--bg-card)',
                        border: '1px solid var(--border-color)',
                        borderRadius: 'var(--radius-md)',
                        display: 'flex',
                        flexDirection: 'column',
                        gap: '8px',
                        transition: 'all 0.15s ease'
                      }}
                    >
                      <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: '8px' }}>
                        <h4 style={{ fontSize: '0.9rem', fontWeight: 600, color: 'var(--text-primary)', lineHeight: 1.3 }}>
                          {task.title}
                        </h4>
                        <span className={`badge badge-${task.priority}`}>
                          {task.priority}
                        </span>
                      </div>

                      {task.description && (
                        <p style={{ fontSize: '0.78rem', color: 'var(--text-muted)', display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', overflow: 'hidden' }}>
                          {task.description}
                        </p>
                      )}

                      {/* Subtask Progress Bar */}
                      {totalSubtasks > 0 && (
                        <div style={{ display: 'flex', flexDirection: 'column', gap: '4px', marginTop: '4px' }}>
                          <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.7rem', color: 'var(--text-muted)', fontWeight: 600 }}>
                            <span>Subtasks</span>
                            <span>{completedSubtasks}/{totalSubtasks} ({subtaskPct}%)</span>
                          </div>
                          <div style={{ width: '100%', height: '4px', background: 'var(--bg-tertiary)', borderRadius: '2px', overflow: 'hidden' }}>
                            <div style={{ width: `${subtaskPct}%`, height: '100%', background: 'var(--accent-primary)', transition: 'width 0.3s ease' }} />
                          </div>
                        </div>
                      )}

                      {/* Tags & Due Date Footer */}
                      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginTop: '6px', flexWrap: 'wrap', gap: '6px' }}>
                        <div style={{ display: 'flex', gap: '4px', flexWrap: 'wrap' }}>
                          {task.tags && task.tags.slice(0, 2).map((t, i) => (
                            <span key={i} style={{ background: 'rgba(255,255,255,0.06)', padding: '2px 6px', borderRadius: '4px', fontSize: '0.7rem', color: 'var(--text-secondary)' }}>
                              #{t}
                            </span>
                          ))}
                        </div>

                        {task.dueDate && (
                          <span style={{ fontSize: '0.7rem', color: new Date(task.dueDate) < new Date() && task.status !== 'done' ? '#ef4444' : 'var(--text-muted)', display: 'flex', alignItems: 'center', gap: '4px' }}>
                            <Icon name="Calendar" size={12} />
                            {task.dueDate}
                          </span>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
