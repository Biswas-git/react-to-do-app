import { useState, useCallback, useRef } from 'react'

export function useUndo() {
  const [history, setHistory] = useState([])
  const [future, setFuture] = useState([])
  const limit = useRef(50)

  const pushHistory = useCallback((snapshot) => {
    setHistory((prev) => {
      const next = [...prev, snapshot]
      if (next.length > limit.current) next.shift()
      return next
    })
    setFuture([])
  }, [])

  const undo = useCallback((currentState, restore) => {
    setHistory((prev) => {
      if (prev.length === 0) return prev
      const last = prev[prev.length - 1]
      setFuture((f) => [currentState, ...f])
      restore(last)
      return prev.slice(0, -1)
    })
  }, [])

  const redo = useCallback((currentState, restore) => {
    setFuture((prev) => {
      if (prev.length === 0) return prev
      const [next, ...rest] = prev
      setHistory((h) => [...h, currentState])
      restore(next)
      return rest
    })
  }, [])

  const canUndo = history.length > 0
  const canRedo = future.length > 0

  return { pushHistory, undo, redo, canUndo, canRedo }
}
