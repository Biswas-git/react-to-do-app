# TaskFlow — Advanced Personal Task Manager

A professional-grade to-do application built with React and Vite. Features Kanban board with drag-and-drop, calendar view, sub-tasks, recurring tasks, labels, command palette, undo/redo, bulk operations, and a beautiful dark/light theme — all persisted in localStorage.

## Features

- Add tasks with title, category, priority, due date, notes, labels, and recurrence
- Edit tasks inline with Save/Cancel support
- Delete tasks with confirmation dialog
- Mark tasks complete/incomplete with animated checkbox
- Sub-tasks with progress tracking per task
- Recurring tasks (Daily, Weekly, Monthly) that auto-regenerate
- Custom labels with color picker
- Filter by status: All / Active / Completed
- Filter by category: Work / Personal / Urgent / Study
- Filter by priority: Low / Medium / High
- Filter by label
- Search tasks by title or notes
- Sort by: Newest, Oldest, Priority, Due Date, A-Z
- Three view modes: List, Kanban Board (drag-and-drop), Calendar
- Stats dashboard with progress bar and overdue/recurring counts
- Command palette (Ctrl+K) for quick actions
- Undo/Redo system (Ctrl+Z / Ctrl+Y)
- Bulk selection with batch complete/delete
- Export tasks as JSON file
- Import tasks from JSON file or pasted text
- Toast notifications for all actions
- Dark/light theme toggle persisted in localStorage
- Fully responsive layout (mobile + desktop)
- Smooth animations and transitions
- Keyboard accessible (Enter to save, Escape to cancel, Ctrl+K for palette)

## Technologies Used

- React 18
- Vite 5
- Plain CSS (CSS variables for theming)
- JavaScript (JSX)

## Setup

```bash
npm install
npm run dev
```

Then open http://localhost:5173 in your browser.

## Screenshots

### Home
![Home](screenshots/home.png)

### Filtered View
![Filtered](screenshots/filtered.png)

### Dark Mode
![Dark Mode](screenshots/dark-mode.png)

## Live Demo

[Live Demo](https://your-demo-link.vercel.app)

## Known Limitations

- No backend — all data is stored in the browser's localStorage
- No drag-and-drop reordering within the list view
- No notifications or reminders
